<?php $__env->startSection('content'); ?>
<div class="panel panel-success">
	<div class="panel-heading">
		<strong>Dashboard - Instructions</strong>
	</div>
	<div class="panel-body font-md">
		<div class="row">
			<div class="col-sm-12">
				<strong class="text-primary">Pages: </strong>
				Here you will find all the active and inactive pages and navigation bars to edit or delete. Though deleting page is not a good practice, you may make the page inactive to hide from the website. You can add any page according to order as well.
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<strong class="text-primary">Page Contents: </strong>
				All the contents of your pages are here. you can add, edit or delete contents by sections with various types. More instructions are given for operating and managing page contents there.
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>