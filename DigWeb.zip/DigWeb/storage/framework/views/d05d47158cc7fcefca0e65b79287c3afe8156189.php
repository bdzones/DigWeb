<?php $webInfos = webInfos() ?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <link href="<?php echo e(!empty($webInfos->logo) ? asset('img/'.$webInfos->logo) : asset('img/sample_logo.jpg')); ?>" rel="icon" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title',!empty($webInfos->name) ? $webInfos->name : config('app.name')); ?></title>

    <!-- fonts -->
    <!-- <link href="https://fonts.googleapis.com/css?family=Bellefair" rel="stylesheet"> --><!-- font-family: 'Bellefair', serif; -->
    
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('web/css/bootstrap-3.3.7.min.css')); ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/sidebar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <!-- jQuery -->
    <script src="<?php echo e(asset('web/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('web/js/bootstrap-3.3.7.min.js')); ?>"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <div id="app">
        <?php echo $__env->make('dboard.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="wrapper">

            <!-- Sidebar -->
            <?php echo $__env->make('dboard.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /#sidebar-wrapper -->

            <!-- Page Content -->
            <div id="page-content-wrapper">
                <div class="container-fluid dark-font">
                    <div class="row">    
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
            <!-- /#page-content-wrapper -->

        </div>
        <!-- /#wrapper -->

    </div>

    <!-- Bootstrap Core JavaScript -->
    <!-- <script src="<?php echo e(asset('web/js/bootstrap-3.3.7.min.js')); ?>"></script> -->

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    /*$('.nav a').on('click', function(){
        //$('.btn-navbar').click(); //bootstrap 2.x
        $('.navbar-toggle').click() //bootstrap 3.x by Richard
    });*/
    </script>

</body>
</html>
