<nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- sidebar toggle -->
                    <a href="#menu-toggle" class="btn btn-info pull-left sidebar-toggle-btn" id="menu-toggle"><i class="fa fa-angle-left bold"></i></a>
                    <!-- Branding Image -->
                    <a class="navbar-brand dboard-brand" href="<?php echo e(url('dboard')); ?>"><img class="img-responsive img-brand-logo" src="<?php echo e(!empty($webInfos->logo) ? asset('img/'.$webInfos->logo) : asset('img/sample_logo.jpg')); ?>" alt="<?php echo e(!empty($webInfos->name) ? $webInfos->name : config('app.name')); ?>"><?php echo e(!empty($webInfos->name) ? $webInfos->name : config('app.name')); ?></a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <!-- <ul class="nav navbar-nav">
                        
                    </ul> -->

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?php echo e(asset('dboard')); ?>">Dashboard</a></li>
                        <li><a href="<?php echo e(asset('page/home')); ?>">Home</a></li>
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu profile-dropdown-menu" role="menu">
                                    <li><a href="<?php echo e(url('profile')); ?>"><i class="fa fa-user"></i> Profile</a></li>
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> 
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>