<?php $__env->startSection('content'); ?>
<?php $page_info = "" ?>
<?php if(Session::has('page_info')): ?>
<?php $page_info = Session::get('page_info') ?>
<?php endif; ?>
<div class="panel panel-default">
	<div class="panel-heading">
		<strong>All Page Contents</strong>
	</div>
	<div class="panel-body">
		
        <ul class="nav nav-tabs">
		<?php if(!empty($pages)): ?>
		<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<?php !empty($page_info->slug) ? $key = $key+1 : '' ?>

		<?php if($menu->parent_id == 0): ?>

        <?php if(count($menu->children) > 0 ): ?>
        <li class="dropdown <?php echo e(!empty($page_info->slug) && count($page_info->sections) > 0 && $page_info->parent_id == $menu->id ? 'active' : ''); ?>">
          	<a class="dropdown-toggle" data-toggle="dropdown" href=""><?php echo e($menu->name); ?></a>
          	<ul class="dropdown-menu">

          	<?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          		<?php if($submenu->status == 1): ?>
            	<li class="<?php echo e(!empty($page_info) && $page_info->slug == $submenu->slug ? 'active' : ''); ?>"><a href="#<?php echo e($submenu->slug); ?>" data-toggle="tab"><i class="fa <?php echo e(!empty($submenu->fa_icon) ? $submenu->fa_icon : ''); ?>"></i> <?php echo e($submenu->name); ?></a></li>
          		<?php endif; ?>

          	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          	</ul>
        </li> 
        <?php else: ?>
        <li class="<?php echo e(!empty($page_info) && $page_info->slug == $menu->slug || $key == 0 ? 'active' : ''); ?>"><a href="#<?php echo e($menu->slug); ?>" data-toggle="tab"><i class="fa <?php echo e(!empty($menu->fa_icon) ? $menu->fa_icon : ''); ?>"></i> <?php echo e($menu->name); ?></a></li>
        <?php endif; ?>

        <?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		</ul>
		
		<div class="tab-content">
		<?php if(!empty($pages)): ?>
		<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<?php !empty($page_info->slug) ? $key = $key+1 : '' ?>

			<div id="<?php echo e($page->slug); ?>" class="tab-pane fade<?php echo e(!empty($page_info->slug) && $page_info->slug == $page->slug || $key == 0 ? ' in active' : ''); ?>">
		    	<h3><?php echo e($page->name); ?>

					<span class="pull-right db-add-btn">
						<a href="<?php echo e(url('add-section',$page->id)); ?>" class="btn btn-sm btn-success bold"><i class="fa fa-plus"></i> Add Section</a>
					</span>
					<span class="pull-right db-add-btn" style="margin-right: 5px;">
						<a href="#sectionHelpModal" data-toggle="modal" class="btn btn-sm btn-info bold"><i class="fa fa-info-circle"></i> Help</a>
					</span>
		    	</h3>

		    	<?php if(!empty($page->sections) && count($page->sections) > 0 ): ?>
		    	<?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    	
		    	<?php if($section->type == 'text'): ?>
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:<?php echo e($section->title); ?> No: <?php echo e($section->order_no); ?>, Total Column: <?php echo e($section->total_column); ?>, Type: <?php echo e($section->type); ?></strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="<?php echo e(url('edit-section',$section->id)); ?>" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="<?php echo e(url('delete-section',$section->id)); ?>" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="<?php echo e(url('add-text',$section->id)); ?>" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Text</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
			    		<div class="row">
			    			<?php $__currentLoopData = $section->texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    			<?php $col = 12/$section->total_column ?>

			    			<div class="col-sm-<?php echo e($col); ?>">
			    				<h3>Title: <?php echo e($text->title ? $text->title : ''); ?>

				    				<span class="pull-right db-add-btn">
										<a href="<?php echo e(url('delete-text',$text->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
									</span> 
				    				<span class="pull-right db-add-btn">
										<a href="<?php echo e(url('edit-text',$text->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
									</span> 
				    			</h3>

				    			<h4>Subtitle: <?php echo e($text->subtitle ? $text->subtitle : ''); ?></h4>
				    			<small>Author: <?php echo e($text->user->name); ?>, Date: <?php echo e(date('d-m-Y h:i:s'), strtotime($text->created_at)); ?></small>

				    			<?php echo $text->details ?>
				    			
			    			</div>

			    			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    		</div>
		    		</div>
		    	</div>
		    	<?php elseif($section->type == 'image'): ?>
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:<?php echo e($section->title); ?> No: <?php echo e($section->order_no); ?>, Total Column: <?php echo e($section->total_column); ?>, Type: <?php echo e($section->type); ?></strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="<?php echo e(url('edit-section',$section->id)); ?>" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="<?php echo e(url('delete-section',$section->id)); ?>" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="<?php echo e(url('add-image',$section->id)); ?>" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Image</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
				    	<div class="row">
				    		<?php $__currentLoopData = $section->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    		<?php $col = 12/$section->total_column ?>

			    			<div class="col-sm-<?php echo e($col); ?>">
				    			<h3>Title: <?php echo e($image->title ? $image->title : ''); ?>

				    				<span class="pull-right db-add-btn">
										<a href="<?php echo e(url('delete-image',$image->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
									</span> 
				    				<span class="pull-right db-add-btn">
										<a href="<?php echo e(url('edit-image',$image->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
									</span> 
				    			</h3>
				    			<h4>Caption: <?php echo e($image->caption ? $image->caption : ''); ?></h4>
				    			<div><strong> Linked to Page: <?php echo e($image->url ? $image->url : 'None'); ?></strong></div>
				    			<small>Author: <?php echo e($image->user->name); ?>, Date: <?php echo e(date('d-m-Y h:i:s'), strtotime($image->created_at)); ?></small>

				    			<div>
				    				<img src="<?php echo e(asset('cntimgs/'.$image->image)); ?>" alt="" class="img-responsive">
				    				<?php if(!empty($image->url)): ?>
				    				Link: <a href="#<?php echo e($image->url); ?>" data-toggle="tab" class="btn btn-info link"><?php echo e($image->url); ?></a>
				    				<?php endif; ?>
				    			</div>
				    			
				    		</div>
				    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    	</div>
		    		</div>
		    	</div>
		    	<?php elseif($section->type == 'article'): ?>
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:<?php echo e($section->title); ?> No: <?php echo e($section->order_no); ?>, Total Column: <?php echo e($section->total_column); ?>, Type: <?php echo e($section->type); ?></strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="<?php echo e(url('edit-section',$section->id)); ?>" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="<?php echo e(url('delete-section',$section->id)); ?>" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="<?php echo e(url('add-article',$section->id)); ?>" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Article</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
				    	<div class="row">
				    		<?php $__currentLoopData = $section->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    		<?php $col = 12/$section->total_column ?>

			    			<div class="col-sm-<?php echo e($col); ?>">
				    			<h3>Title: <?php echo e($article->title ? $article->title : ''); ?>

				    				<span class="pull-right db-add-btn">
										<a href="<?php echo e(url('delete-article',$article->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
									</span> 
				    				<span class="pull-right db-add-btn">
										<a href="<?php echo e(url('edit-article',$article->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
									</span> 
				    			</h3>
				    			<h4>Subtitle: <?php echo e($article->subtitle ? $article->subtitle : ''); ?></h4>
				    			<small>Author: <?php echo e($article->user->name); ?>, Date: <?php echo e(date('d-m-Y h:i:s'), strtotime($article->created_at)); ?></small>

				    			<div>
				    				<img src="<?php echo e(asset('cntimgs/'.$article->image)); ?>" alt="" class="img-responsive">
				    			</div>
				    			
				    			<?php echo $article->details ?>
				    		</div>
				    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    	</div>
		    		</div>
		    	</div>
		    	<?php elseif($section->type == 'slide'): ?>
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:<?php echo e($section->title); ?> No: <?php echo e($section->order_no); ?>, Total Column: <?php echo e($section->total_column); ?>, Type: <?php echo e($section->type); ?></strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="<?php echo e(url('edit-section',$section->id)); ?>" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="<?php echo e(url('delete-section',$section->id)); ?>" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="<?php echo e(url('add-slide',$section->id)); ?>" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Slide Image</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
				    	<div class="row">
				    	<?php if(!empty($section->slides) && count($section->slides) > 0): ?>
				    		
				    		<?php $col = 12/$section->total_column ?>

			    			<div class="col-sm-<?php echo e($col); ?>">
			    			
				    			<!-- start carousel -->
								<div class="carousel-container">
								    <div id="myCarousel<?php echo e($section->id); ?>" class="carousel slide carousel-fade">  
							        	<div class="carousel-inner">
							        	<?php $__currentLoopData = $section->slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        		<div class="item <?php echo e($key == 0 ? ' active' : ''); ?>">
							        		<h3>Title: <?php echo e($slide->title ? $slide->title : ''); ?>

							    				<span class="pull-right db-add-btn">
													<a href="<?php echo e(url('delete-slide',$slide->id)); ?>" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
												</span> 
							    				<span class="pull-right db-add-btn">
													<a href="<?php echo e(url('edit-slide',$slide->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
												</span> 
							    			</h3>
							        			
							        		</span>
							              		<img src="<?php echo e(asset('cntimgs/'.$slide->image)); ?>" alt="<?php echo e($slide->caption); ?>">
							              		<div class="container">
							                		<div class="carousel-caption">
							                  			<p class="caption animated bounceInUp"><?php echo e($slide->caption); ?></p>
							                		</div>
							              		</div>
							            	</div>
							            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        	
									        <!-- Controls -->
									        <a class="left carousel-control" href="#myCarousel<?php echo e($section->id); ?>" data-slide="prev"><span class="fa fa-chevron-left"></span></a>
									        <a class="right carousel-control" href="#myCarousel<?php echo e($section->id); ?>" data-slide="next"><span class="fa fa-chevron-right"></span></a>
							      		</div>
							    	</div>
							    </div>

							  	<!-- end carousel -->
				    			<script>
									// carousel interval
									$("#myCarousel<?php echo e($section->id); ?>").carousel({interval: 2000});
								  	// Register keyboard events
								  	$(document).keydown(function(e) {
								    	if (e.keyCode === 37) {
								       		// Previous
								       		$(".carousel-control.left").click();
								       		return false;
								    	}
								    	if (e.keyCode === 39) {
								       		// Next
								       		$(".carousel-control.right").click();
								       		return false;
								    	}
									});
								</script>
							
				    		</div>
				    	<?php endif; ?>
				    	</div>
		    		</div>
		    	</div>
		    	<?php endif; ?>

		    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	<?php endif; ?>
		    	
		  	</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		</div>
		
	</div>
</div>
<!-- Modal -->
<div id="sectionHelpModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">FAQ about Section</h4>
      </div>
      <div class="modal-body font-md">
        <ul class="list-group">
		  <li class="list-group-item">1. Every page is generated with sections. A page has one or more sections. This is the primary part for a page to add something according to type.</li>
		  <li class="list-group-item text-primary">2. There are 4 types of section. 1 - Text type which contains only textual contents, 2 - Image type whiche contains only image type contents, 3 - Article type which can contain both text and image content and 4 - Slide type which contains image slider.</li>
		  <li class="list-group-item text-danger">3. Every section must be defined which type it is and what is the order no of the section for it's associative page.</li>
		  <li class="list-group-item text-danger">4. Total Column number is essential to set how many columsn will take the section. For Slide type section, you should never set column number more than 1. If you want to show 2 mages per row or as a set in the section i image type section just set column no as 2. If you skip the field, system will set total column no 1 by default.</li>
		</ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>