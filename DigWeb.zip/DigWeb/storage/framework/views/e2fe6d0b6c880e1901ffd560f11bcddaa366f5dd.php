<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">
	<div class="panel-heading">
		<strong>Web Information</strong>
		<span class="pull-right db-add-btn">
			<a href="<?php echo e(!empty($web_infos) ? url('edit-web-infos') : url('add-web-infos')); ?>" class="btn btn-sm btn-default"><i class="fa fa-<?php echo e(!empty($web_infos) ? 'edit' : 'plus'); ?>"></i> <?php echo e(!empty($web_infos) ? 'Edit' : 'Add'); ?></a>
		</span>
	</div>
	<div class="panel-body">
        <div class="row">
            <div class="col-sm-6 col-app-info">
                <div>App Name: <strong><?php echo e(!empty($web_infos->name) ? $web_infos->name : config('app.name')); ?></strong></div>
                <div>Subtitle: <strong><?php echo e(!empty($web_infos->subtitle) ? $web_infos->subtitle : config('app.subtitle')); ?></strong></div>
                <div>Email: <strong><?php echo e(!empty($web_infos->email) ? $web_infos->email : config('app.email')); ?></strong></div>
                <div>Contact No: <strong><?php echo e(!empty($web_infos->contact_no) ? $web_infos->contact_no : config('app.contact_no')); ?></strong></div>
                <div>Website: <strong><?php echo e(!empty($web_infos->website) ? $web_infos->website : config('app.website')); ?></strong></div>
                <div>Address: <strong><?php echo !empty($web_infos->address) ? $web_infos->address : config('app.address') ?></strong></div>
                <div>Owner: <strong><?php echo e(!empty($web_infos->owner) ? $web_infos->owner : config('app.owner')); ?></strong></div>
            </div>
            <div class="col-sm-6">
            <?php if(!empty($web_infos->logo)): ?>
                <img src="<?php echo e(asset('img/'.$web_infos->logo)); ?>" alt="<?php echo e(config('app.name')); ?>" class="img-responsive img-thumbnail app-logo">
            <?php else: ?>
                <img src="<?php echo e(asset('img/sample_logo.jpg')); ?>" alt="<?php echo e(config('app.name')); ?>" class="img-responsive img-thumbnail app-logo">
            <?php endif; ?>
            </div>
        </div>
        <div class="row col-app-info">
            <div class="col-sm-12"><strong>Details:</strong></div>
            <div class="col-sm-12">
                <strong><?php echo !empty($web_infos->details) ? $web_infos->details : config('app.details') ?></strong>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>