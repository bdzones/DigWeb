<?php $__env->startSection('content'); ?>
<div class="panel panel-success">
    <div class="panel-heading text-center">
        <strong><?php echo e(!empty($edit_row) ? 'Edit' : 'Add'); ?> Section to Page <?php echo e($page->name); ?></strong>
    </div>
    <div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(!empty($edit_row) ? url('update-section',[$edit_row->id]) : url('store-section')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php if(!empty($edit_row)): ?>
            <?php echo e(method_field('PATCH')); ?>

            <?php endif; ?>

            <?php if(Session::has('message')): ?>
            <div class="row">
                <div class="col-sm-6 col-sm-offset-2 alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Warning!</strong> <?php echo e(Session::get('message')); ?>

                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($page)): ?>
            <div class="form-group<?php echo e($errors->has('cntwb_id') ? ' has-error' : ''); ?>">
                <label for="cntwb_id" class="col-sm-2 control-label">Page</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="cntwb_id" value="<?php echo e($page->name); ?>" disabled="">
                    <input type="hidden" name="cntwb_id" value="<?php echo e($page->id); ?>">
                    <?php if($errors->has('cntwb_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('cntwb_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>
            <?php endif; ?>

            <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                <label for="type" class="col-sm-2 control-label">Type</label>
                <div class="col-sm-6">
                    <select name="type" id="type" class="form-control" required="">
                        <option value="">select</option>
                        <option value="slide" <?php echo e(!empty($edit_row) && $edit_row->type == 'slide' || old('type') == 'slide' ? 'selected' : ''); ?>>Slide (image for slide only)</option>
                        <option value="text" <?php echo e(!empty($edit_row) && $edit_row->type == 'text' || old('type') == 'text' ? 'selected' : ''); ?>>Text (only text content)</option>
                        <option value="image" <?php echo e(!empty($edit_row) && $edit_row->type == 'image' || old('type') == 'image' ? 'selected' : ''); ?>>Image (only image content)</option>
                        <option value="article" <?php echo e(!empty($edit_row) && $edit_row->type == 'article' || old('type') == 'article' ? 'selected' : ''); ?>>Article (obviously text with image)</option>
                    </select>
                    <?php if($errors->has('type')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('type')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                <label for="title" class="col-sm-2 control-label">Title</label>
                <div class="col-sm-6">
                    <input id="title" type="text" class="form-control" name="title" value="<?php echo e(!empty($edit_row->title) ? $edit_row->title : old('title')); ?>"  placeholder="add title here..">
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-2 text-info">Optional</div>
            </div>

            <div class="form-group">
                <label for="" class="col-sm-2 control-label text-primary">Note</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control text-primary" value="The numbers of columns in this section from 1 to 12. (default 1)" disabled="">
                </div>
                <div class="col-sm-2 text-primary">Note</div>
            </div>

            <div class="form-group<?php echo e($errors->has('total_column') ? ' has-error' : ''); ?>">
                <label for="total_column" class="col-sm-2 control-label">Total Columns</label>
                <div class="col-sm-5">
                    <input id="total_column" type="number" class="form-control" name="total_column" value="<?php echo e(!empty($edit_row->total_column) ? $edit_row->total_column : old('total_column')); ?>" placeholder="0">
                    <?php if($errors->has('total_column')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('total_column')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-1">
                    <button type="button" class="btn btn-info btn-block" data-toggle="modal" data-target="#totalColumnHelpModal"><i class="fa fa-info-circle"></i> Help</button>
                </div>
                <div class="col-sm-2 text-info">Optional</div>
            </div>

            <!-- total column Modal -->
            <div id="totalColumnHelpModal" class="modal fade" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title text-center">About Total Column</h4>
                        </div>
                        <div class="modal-body bold">
                            <ul class="list-group">
                                <li class="list-group-item text-primary">1. Total column no set that how many column you want to show for the section. If you set the value 2 the section will be sliced in tow equal parts, if you set the value 3 the section will be sliced in 3 equal parts.</li>
                            </ul>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('order_no') ? ' has-error' : ''); ?>">
                <label for="order_no" class="col-sm-2 control-label">Order No</label>
                <div class="col-sm-5">
                    <input id="order_no" type="number" class="form-control" name="order_no" value="<?php echo e(!empty($edit_row->order_no) ? $edit_row->order_no : old('order_no')); ?>" required="" placeholder="0">
                    <?php if($errors->has('order_no')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('order_no')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-1">
                    <button type="button" class="btn btn-info btn-block" data-toggle="modal" data-target="#orderNoHelpModal"><i class="fa fa-info-circle"></i> Help</button>
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <!-- order no Modal -->
            <div id="orderNoHelpModal" class="modal fade" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title text-center">About Order No</h4>
                        </div>
                        <div class="modal-body bold">
                            <ul class="list-group">
                                <li class="list-group-item text-primary">1. Section's order no defines the ordering position according to number for the section.</li>
                                <li class="list-group-item text-primary">2. If you set order no 1 that will be the first section for the associative page, and if you set 2 that will be the 2nd section for the page.</li>
                                <li class="list-group-item text-primary">3. Suppose you set 4 section for a page and set 3, 5, 4, 1 order no for them. The sorting of the section in that page will be 1-3-4-5. If you make section 1 inactive order will be repllaced as 3-4-5.</li>
                            </ul>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('padding') ? ' has-error' : ''); ?>">
                <label for="padding" class="col-sm-2 control-label">Padding</label>
                <div class="col-sm-5">
                    <input id="padding" type="text" class="form-control" name="padding" value="<?php echo e(!empty($edit_row->padding) ? $edit_row->padding : old('padding')); ?>" placeholder="0">
                    <?php if($errors->has('padding')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('padding')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-1">
                    <button type="button" class="btn btn-info btn-block" data-toggle="modal" data-target="#PaddingHelpModal"><i class="fa fa-info-circle"></i> Help</button>
                </div>
                <div class="col-sm-2 text-info">Optional</div>
            </div>

            <!-- paddinghelp Modal -->
            <div id="PaddingHelpModal" class="modal fade" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title text-center">About Padding</h4>
                        </div>
                        <div class="modal-body bold">
                            <ul class="list-group">
                                <li class="list-group-item text-danger">1. If you have no knowledge about css padding value please do nothing or set 0 in the input field.</li>
                                <li class="list-group-item text-success">2. If you have knowledge about css padding value what is the effect of this in styling a webpage just set the padding value for the section.</li>
                                <li class="list-group-item text-primary">3. Padding: <span class="text-primary">0px</span> means it will effect nothing on the section.</li>
                                <li class="list-group-item text-primary">4. Padding: <span class="text-primary">15px 10px</span> means it will leave 15px space from the <span class="text-info">Top</span> and 15px space from <span class="text-info">Bottom</span> 10px space from the <span class="text-info">Right</span> and 10px space from <span class="text-info">Left</span> in the section.</li>
                                <li class="list-group-item text-primary">5. Padding: <span class="text-primary">15px 20px 25px 30px</span> means it will leave 15px space from the <span class="text-info">Top</span> and 20px space from <span class="text-info">Right</span> 25px space from the <span class="text-info">Bottom</span> and 30px space from <span class="text-info">Left</span> in the section.</li>
                                <li class="list-group-item text-primary">6. Padding Valuse Sorting: <span class="text-primary">Top Right Bottom Left</span> that set all by numaric <span class="text-primary">px</span> value</li>
                            </ul>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('bg_color') ? ' has-error' : ''); ?>">
                <label for="bg_color" class="col-sm-2 control-label">Background Color</label>
                <div class="col-sm-5">
                    <input id="bg_color" type="text" class="form-control" name="bg_color" value="<?php echo e(!empty($edit_row->bg_color) ? $edit_row->bg_color : old('bg_color')); ?>">
                    <?php if($errors->has('bg_color')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('bg_color')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-1">
                    <button type="button" class="btn btn-info btn-block" data-toggle="modal" data-target="#BGHelpModal"><i class="fa fa-info-circle"></i> Help</button>
                </div>
                <div class="col-sm-2 text-info">Optional</div>
            </div>

            <!-- background color Modal -->
            <div id="BGHelpModal" class="modal fade" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title text-center">About Background Color</h4>
                        </div>
                        <div class="modal-body bold">
                            <ul class="list-group">
                                <li class="list-group-item text-primary">1. Set a background color for the section</li>
                                <li class="list-group-item text-success">2. Value formate: any color name that is supported by web browsers like red, green, black, white, blue, crimson, cyan, navy etc.</li>
                                <li class="list-group-item text-success">3. Value formate: any hexadecimal color code like #FFFFF for white, #F20C0C for red, #000000 for black etc.</li>
                                <li class="list-group-item text-success">4. Value formate: any rgb code rgb(12,31,242) for blue, rgb(249,249,2) for yellow, rgb(255,255,255) for white, rgb(0,0,0) for black and etc.</li>
                                <li class="list-group-item text-success">5. Value formate: any rgba code rgb(12,31,242, .5) for blue 50% transparent, rgb(249,249,2, .2) for yellow 20% transparent, rgb(255,255,255, .75) for white 75% transparent, rgb(0,0,0, 1) for black 10% transparent and etc.</li>
                                <li class="list-group-item">6. The default color is white</li>
                                <li class="list-group-item text-danger">7. Do nothing if you have no idea about website background color.</li>
                            </ul>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('font_color') ? ' has-error' : ''); ?>">
                <label for="font_color" class="col-sm-2 control-label">Font Color</label>
                <div class="col-sm-5">
                    <input id="font_color" type="text" class="form-control" name="font_color" value="<?php echo e(!empty($edit_row->font_color) ? $edit_row->font_color : old('font_color')); ?>">
                    <?php if($errors->has('font_color')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('font_color')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-1">
                    <button type="button" class="btn btn-info btn-block" data-toggle="modal" data-target="#fontColorHelpModal"><i class="fa fa-info-circle"></i> Help</button>
                </div>
                <div class="col-sm-2 text-info">Optional</div>
            </div>

            <!-- paddinghelp Modal -->
            <div id="fontColorHelpModal" class="modal fade" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title text-center">About Font Color</h4>
                        </div>
                        <div class="modal-body bold">
                            <ul class="list-group">
                                <li class="list-group-item text-primary">1. Sometimes you may face problem with font color for any background color of the section. Suppose you have select section background colol black and the default font color is also dark, so the text in the section may not be readable for the user. In that case you can chabge the font color here.</li>
                                <li class="list-group-item text-primary">2. Color value conditions are same as the for the background color.</li>
                            </ul>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('text_align') ? ' has-error' : ''); ?>">
                <label for="text_align" class="col-sm-2 control-label">Text Align</label>
                <div class="col-sm-6">
                    <select name="text_align" id="text_align" class="form-control">
                        <option value="">select</option>
                        <option value="left" <?php echo e(!empty($edit_row->text_align) && $edit_row->text_align == 'left' || old('text_align') == 'left' ? 'selected' : ''); ?>>Left</option>
                        <option value="right" <?php echo e(!empty($edit_row->text_align) && $edit_row->text_align == 'right' || old('text_align') == 'right' ? 'selected' : ''); ?>>Right</option>
                        <option value="center" <?php echo e(!empty($edit_row->text_align) && $edit_row->text_align == 'center' || old('text_align') == 'center' ? 'selected' : ''); ?>>Center</option>
                        <option value="justify" <?php echo e(!empty($edit_row->text_align) && $edit_row->text_align == 'justify' || old('text_align') == 'justify' ? 'selected' : ''); ?>>Justify</option>
                    </select>
                    <?php if($errors->has('text_align')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('text_align')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-2 text-info">Optional</div>
            </div>

            <div class="form-group<?php echo e($errors->has('section_width') ? ' has-error' : ''); ?>">
                <label for="section_width" class="col-sm-2 control-label">Section Width</label>
                <div class="col-sm-6">
                    <label class="radio-inline bold"><input type="radio" name="section_width" value="2" <?php echo e(!empty($edit_row) && $edit_row->section_width == 2 ? 'checked' : ''); ?>>Full Width</label>
                    <label class="radio-inline bold"><input type="radio" name="section_width" value="1" <?php echo e(!empty($edit_row) && $edit_row->section_width == '1' ? 'checked' : ''); ?>>Moderate (leaving comfort space in both side) </label>
                    <?php if($errors->has('section_width')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('section_width')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('content_width') ? ' has-error' : ''); ?>">
                <label for="content_width" class="col-sm-2 control-label">Content Width</label>
                <div class="col-sm-6">
                    <label class="radio-inline bold"><input type="radio" name="content_width" value="2" <?php echo e(!empty($edit_row) && $edit_row->content_width == 2 ? 'checked' : ''); ?>>Full Width</label>
                    <label class="radio-inline bold"><input type="radio" name="content_width" value="1" <?php echo e(!empty($edit_row) && $edit_row->content_width == '1' ? 'checked' : ''); ?>>Moderate (leaving comfort space in both side) </label>
                    <?php if($errors->has('content_width')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('content_width')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                <label for="status" class="col-sm-2 control-label">Status</label>
                <div class="col-sm-6">
                    <label class="radio-inline"><input type="radio" name="status" value="1" checked=""<?php echo e(!empty($edit_row) && $edit_row->status == 1 ? 'checked' : ''); ?>>Active</label>
                    <label class="radio-inline"><input type="radio" name="status" value="2" <?php echo e(!empty($edit_row) && $edit_row->status == 2 ? 'checked' : ''); ?>>Inactive</label>
                    <?php if($errors->has('status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-6 col-sm-offset-2">
                    <div class="col-sm-6">
                        <div class="row">
                            <button type="submit" class="btn btn-primary btn-block">
                            <?php echo e(!empty($edit_row->id) ?  'Update' : 'Save'); ?>

                        </button>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <input type="reset" class="btn btn-warning btn-block">
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>