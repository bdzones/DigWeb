<?php $webInfos = webInfos() ?>
        <nav class="navbar navbar-default navbar-fixed-top<?php echo e(Auth::user() && Auth::user()->weight >= 79.99 ? ' dbar-nav' : ''); ?>">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img class="img-responsive logo" src="<?php echo e(!empty($webInfos->logo) ? asset('img/'.$webInfos->logo) : asset('img/sample_logo.jpg')); ?>" alt="<?php echo e(!empty($webInfos->name) ? $webInfos->name : config('app.name')); ?>"></a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <!-- <ul class="nav navbar-nav">
                        
                    </ul> -->

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <?php $menus = menuArray() ?>

                        <?php if(!empty($menus)): ?>
                        
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($menu->parent_id == 0): ?>

                        <?php if(count($menu->children) > 0 ): ?>
                        <li class="dropdown">
                          <a class="dropdown-toggle" data-toggle="dropdown" href=""><?php echo e($menu->name); ?></a>
                          <ul class="dropdown-menu nav-dropdown">

                          <?php $__currentLoopData = $menu->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <?php if($submenu->status == 1): ?>
                            <li><a href="<?php echo e(url('page',$submenu->slug)); ?>"><i class="fa <?php echo e(!empty($submenu->fa_icon) ? $submenu->fa_icon : ''); ?>"></i> <?php echo e($submenu->name); ?></a></li>
                          <?php endif; ?>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </ul>
                        </li> 
                        <?php else: ?>
                        <li><a href="<?php echo e(url('page',$menu->slug)); ?>"><i class="fa <?php echo e(!empty($menu->fa_icon) ? $menu->fa_icon : ''); ?>"></i> <?php echo e($menu->name); ?></a></li>
                        <?php endif; ?>

                        <?php endif; ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php endif; ?>
                        <!-- Authentication Links -->
                        
                    </ul>
                </div>
            </div>
        </nav>