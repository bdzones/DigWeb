<?php $__env->startSection('title',$page->name); ?>
<?php $__env->startSection('content'); ?>

<?php if(!empty($page->sections) && count($page->sections) > 0): ?>

<?php if($page->slug != 'home'): ?>
<div class="container-fluid">
	<div class="row">
		<div class="container mt30">
			<h1 class="page-title"><?php echo e($page->name); ?></h1>
			<hr>
		</div>
	</div>
</div>
<?php endif; ?>

<?php $__currentLoopData = $page->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($section->type == 'text' && count($section->texts) > 0 ): ?>
<div class="container<?php echo e(!empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid'); ?> <?php echo e($section->id == 4 ? 'sp-bg' : ''); ?>" style="background-color: <?php echo e(!empty($section->bg_color) ? $section->bg_color : 'transparent'); ?>;color: <?php echo e(!empty($section->font_color) ? $section->font_color : 'inherit'); ?>; padding:<?php echo e(!empty($section->padding) ? $section->padding : '0'); ?>;text-align: <?php echo e(!empty($section->text_align) ? $section->text_align : ''); ?>;">
	<div class="">
		<section id="<?php echo e($section->id); ?>" class="container<?php echo e(!empty($section->content_width) && $section->content_width == 1 ? '' : '-fluid'); ?>">

			<?php if(!empty($section->title)): ?>
			<div class="col-sm-12">
				<h2 class="section-heading"><?php echo e($section->title); ?></h2>
			</div>
			<?php endif; ?>

			<?php $__currentLoopData = $section->texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $col = 12/$section->total_column ?>
			<div class="col-sm-<?php echo e($col); ?>">
				
				<?php if($section->id != 4): ?>
				<?php if(!empty($text->title)): ?>
				<div class="row">
					<h1><b><?php echo e($text->title); ?></b></h1>
				</div>
				<?php endif; ?>
				<?php endif; ?>

				<?php if(!empty($text->subtitle)): ?>
				<div><i><?php echo e($text->subtitle); ?></i></div>
				<?php endif; ?>

				<div class="row">
					<?php echo $text->details ? $text->details : '' ?>
				</div>

			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</section>
	</div>
</div>
<?php elseif($section->type == 'article' && count($section->articles) > 0 ): ?>
<div class="container<?php echo e(!empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid'); ?>" style="background-color: <?php echo e(!empty($section->bg_color) ? $section->bg_color : 'transparent'); ?>; color: <?php echo e(!empty($section->font_color) ? $section->font_color : 'inherit'); ?>; padding:<?php echo e(!empty($section->padding) ? $section->padding : '0'); ?>;text-align: <?php echo e(!empty($section->text_align) ? $section->text_align : ''); ?>;">
	<div class="">
		<section id="<?php echo e($section->id); ?>" class="container<?php echo e(!empty($section->content_width) && $section->content_width == 1 ? '' : '-fluid'); ?>">

			<?php if(!empty($section->title)): ?>
			<div class="col-sm-12">
				<h2 class="section-heading"><?php echo e($section->title); ?></h2>
				<?php echo e($section->font_color); ?>

			</div>
			<?php endif; ?>

			<?php $__currentLoopData = $section->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $col = 12/$section->total_column ?>
			<div class="col-sm-<?php echo e($col); ?>">
				
				<?php if(!empty($article->title)): ?>
				<h3><b><?php echo e($article->title); ?></b></h3>
				<?php endif; ?>

				<?php if(!empty($article->subtitle)): ?>
				<div><i><?php echo e($article->subtitle); ?></i></div>
				<?php endif; ?>

				<?php if(!empty($article->image)): ?>
				<div class="art-img-box"><img src="<?php echo e(asset('cntimgs/'.$article->image)); ?>" alt="<?php echo e($article->title); ?>" class="img-responsive"></div>
				<?php endif; ?>			

				<?php echo $text->details ? $text->details : '' ?>

			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</section>
	</div>
</div>
<?php elseif($section->type == 'image' && count($section->images) > 0 ): ?>
<div class="container<?php echo e(!empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid'); ?>" style="background-color: <?php echo e(!empty($section->bg_color) ? $section->bg_color : 'transparent'); ?>; color: <?php echo e(!empty($section->font_color) ? $section->font_color : 'inherit'); ?>; padding:<?php echo e(!empty($section->padding) ? $section->padding : '0'); ?>;text-align: <?php echo e(!empty($section->text_align) ? $section->text_align : ''); ?>;">
	<div class="">
		<section id="<?php echo e($section->id); ?>" class="container<?php echo e(!empty($section->content_width) && $section->content_width == 1 ? '' : '-fluid'); ?>">

			<?php if(!empty($section->title)): ?>
			<div class="">
				<h2 class="section-heading"><?php echo e($section->title); ?></h2>
			</div>
			<?php endif; ?>

			<?php $i = 1; $total = $section->images->count() ?>
			<div class="row">
			<?php $__currentLoopData = $section->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $col = 12/$section->total_column ?>
			<div class="col-sm-<?php echo e($col); ?> text-center">
				
				<div class="pro-img-box">
					<div class="pro-img">
						<img src="<?php echo e(asset('cntimgs/'.$image->image)); ?>" alt="<?php echo e($image->title); ?>" class="img-responsive">
					</div>
					<?php if(!empty($image->title)): ?>
					<div class="mt15 font-md">
						<strong><?php echo e($image->title); ?></strong>
					</div>
					<?php endif; ?>
					<?php if(!empty($image->caption)): ?>
					<div class="mb10">
						<?php echo e($image->caption); ?>

					</div>
					<?php endif; ?>
					<?php if($page->parent_id != '3'): ?>
					<div class="mt15">
						<a href="<?php echo e(url('page',$image->url)); ?>" class="btn btn-primary btn-product">Read More</a>
					</div>
					<?php endif; ?>
				</div>

			</div>
			<?php if($total > $section->total_column && $i % $section->total_column == 0): ?>
			</div>
			<div class="row">
			<?php endif; ?>
			<?php $i++ ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

		</section>
	</div>
</div>
<?php elseif($section->type == 'slide' && count($section->slides) > 0 ): ?>
<div class="container<?php echo e(!empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid'); ?>" style="background-color: <?php echo e(!empty($section->bg_color) ? $section->bg_color : 'transparent'); ?>; color: <?php echo e(!empty($section->font_color) ? $section->font_color : 'inherit'); ?>; padding:<?php echo e(!empty($section->padding) ? $section->padding : '0'); ?>;text-align: <?php echo e(!empty($section->text_align) ? $section->text_align : ''); ?>;">
	<div class="">
		<section id="<?php echo e($section->id); ?>" class="">

			<?php if(!empty($section->title)): ?>
			<div class="col-sm-12">
				<h2 class="section-heading"><?php echo e($section->title); ?></h2>
			</div>
			<?php endif; ?>

			<?php $col = 12/$section->total_column ?>
			<div class="col-sm-<?php echo e($col); ?>">

				<div class="row">
					<!-- start carousel -->
					<div class="carousel-container">
					    <div id="myCarousel<?php echo e($section->id); ?>" class="carousel slide carousel-fade">  
				        	<div class="carousel-inner">
				        	<?php $__currentLoopData = $section->slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        		<div class="item <?php echo e($key == 0 ? ' active' : ''); ?>">	
				        		</span>
				              		<img src="<?php echo e(asset('cntimgs/'.$slide->image)); ?>" alt="<?php echo e($slide->caption); ?>">
				              		<div class="container">
				                		<div class="carousel-caption">
				                  			<p class="caption animated bounceInUp"><?php echo e($slide->caption); ?></p>
				                		</div>
				              		</div>
				            	</div>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        	
						        <!-- Controls -->
						        <a class="left carousel-control" href="#myCarousel<?php echo e($section->id); ?>" data-slide="prev"><span class="fa fa-chevron-left"></span></a>
						        <a class="right carousel-control" href="#myCarousel<?php echo e($section->id); ?>" data-slide="next"><span class="fa fa-chevron-right"></span></a>
				      		</div>
				    	</div>
				    </div>

				  	<!-- end carousel -->
					<script>
						// carousel interval
						$("#myCarousel<?php echo e($section->id); ?>").carousel({interval: 2000});
					  	// Register keyboard events
					  	$(document).keydown(function(e) {
					    	if (e.keyCode === 37) {
					       		// Previous
					       		$(".carousel-control.left").click();
					       		return false;
					    	}
					    	if (e.keyCode === 39) {
					       		// Next
					       		$(".carousel-control.right").click();
					       		return false;
					    	}
						});
					</script>
				</div>

			</div>

		</section>
	</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>

<div class="container text-center" style="min-height: 400px; align-items: center;justify-content: center;display: flex;">
	<h2><?php echo e($page->name); ?> - No content added</h2>
</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>