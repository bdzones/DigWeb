<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <div class="panel-heading text-center">
        <strong>Add Text to Section: <span class="text-primary"><?php echo e($section->order_no); ?></span> of Page: <span class="text-primary"><?php echo e($page->name); ?></span></strong>
        <!-- <span class="pull-right db-add-btn">
            <a href="<?php echo e(url('all-texts')); ?>" class="btn btn-sm btn-info bold"><i class="fa fa-plus"></i> All Text Contents</a>
        </span> -->
    </div>
    <div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(!empty($edit_row) ? url('update-text',[$edit_row->id]) : url('store-text')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php if(!empty($edit_row)): ?>
            <?php echo e(method_field('PATCH')); ?>

            <?php endif; ?>

            <?php if(Session::has('message')): ?>
            <div class="row">
                <div class="col-sm-6 col-sm-offset-2 alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Warning!</strong> <?php echo e(Session::get('message')); ?>

                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($langs)): ?>
            <div class="form-group<?php echo e($errors->has('lang_id') ? ' has-error' : ''); ?>">
                <label for="lang_id" class="col-sm-2 control-label">Language</label>
                <div class="col-sm-6">
                    <select name="lang_id" id="lang_id" class="form-control">
                        <option value="">select</option>
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lang->id); ?>" <?php echo e(!empty($edit_row) && $edit_row->lang_id == $lang->id || old('lang_id') == $lang->id ? 'selected' : ''); ?>><?php echo e($lang->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('lang_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('lang_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($page)): ?>
            <div class="form-group<?php echo e($errors->has('cntwb_id') ? ' has-error' : ''); ?>">
                <label for="cntwb_id" class="col-sm-2 control-label">Page</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="cntwb_id" value="<?php echo e($page->name); ?>" disabled="">
                    <input type="hidden" name="cntwb_id" value="<?php echo e($page->id); ?>">
                    <input type="hidden" name="cntsec_id" value="<?php echo e($section->id); ?>">
                    <?php if($errors->has('cntwb_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('cntwb_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                <label for="title" class="col-sm-2 control-label">Title</label>
                <div class="col-sm-6">
                    <input id="title" type="text" class="form-control" name="title" value="<?php echo e(!empty($edit_row->title) ? $edit_row->title : old('title')); ?>" autofocus="" placeholder="add title here..">
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-2 text-info">Optional</div>
            </div>

            <div class="form-group<?php echo e($errors->has('subtitle') ? ' has-error' : ''); ?>">
                <label for="subtitle" class="col-sm-2 control-label">Subtitle</label>
                <div class="col-sm-6">
                    <input id="subtitle" type="text" class="form-control" name="subtitle" value="<?php echo e(!empty($edit_row->subtitle) ? $edit_row->subtitle : old('subtitle')); ?>" placeholder="add subtitle here...">
                    <?php if($errors->has('subtitle')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('subtitle')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('order_no') ? ' has-error' : ''); ?>">
                <label for="order_no" class="col-sm-2 control-label">Order No</label>
                <div class="col-sm-6">
                    <input id="order_no" type="number" class="form-control" name="order_no" value="<?php echo e(!empty($edit_row->order_no) ? $edit_row->order_no : old('order_no')); ?>">
                    <?php if($errors->has('order_no')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('order_no')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('details') ? ' has-error' : ''); ?>">
                <label for="details" class="col-sm-2 control-label">Details</label>
                <div class="col-sm-6">
                    <textarea name="details" id="details" cols="10" rows="5" class="form-control" placeholder="add details here..." required=""><?php echo e(!empty($edit_row->details) ? $edit_row->details : old('details')); ?></textarea>
                    <?php if($errors->has('details')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('details')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                <label for="status" class="col-sm-2 control-label">Status</label>
                <div class="col-sm-6">
                    <label class="radio-inline"><input type="radio" name="status" value="1" checked="" <?php echo e(!empty($edit_row) && $edit_row->status == 1 ? 'checked' : ''); ?>>Active</label>
                    <label class="radio-inline"><input type="radio" name="status" value="2" <?php echo e(!empty($edit_row) && $edit_row->status == 2 ? 'checked' : ''); ?>>Inactive</label>
                    <?php if($errors->has('status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-6 col-sm-offset-2">
                    <div class="col-sm-6">
                        <div class="row">
                            <button type="submit" class="btn btn-primary btn-block">
                            <?php echo e(!empty($edit_row->id) ?  'Update' : 'Save'); ?>

                        </button>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <input type="reset" class="btn btn-warning btn-block">
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>
    CKEDITOR.replace('details');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>