<?php $__env->startSection('content'); ?>
<div class="panel panel-success">
    <div class="panel-heading text-center">
        <strong>Add Image to Section: <span class="text-primary"><?php echo e($section->order_no); ?></span> of Page: <span class="text-primary"><?php echo e($page->name); ?></span></strong>
        <!-- <span class="pull-right db-add-btn">
            <a href="<?php echo e(url('all-images')); ?>" class="btn btn-sm btn-info bold"><i class="fa fa-plus"></i> All Image</a>
        </span> -->
    </div>
    <div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(!empty($edit_row) ? url('update-image',[$edit_row->id]) : url('store-image')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php if(!empty($edit_row)): ?>
            <?php echo e(method_field('PATCH')); ?>

            <?php endif; ?>

            <?php if(Session::has('message')): ?>
            <div class="row">
                <div class="col-sm-6 col-sm-offset-2 alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Warning!</strong> <?php echo e(Session::get('message')); ?>

                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($langs)): ?>
            <div class="form-group<?php echo e($errors->has('lang_id') ? ' has-error' : ''); ?>">
                <label for="lang_id" class="col-sm-2 control-label">Language</label>
                <div class="col-sm-6">
                    <select name="lang_id" id="lang_id" class="form-control">
                        <option value="">select</option>
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lang->id); ?>" <?php echo e(!empty($edit_row) && $edit_row->lang_id == $lang->id || old('lang_id') == $lang->id ? 'selected' : ''); ?>><?php echo e($lang->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('lang_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('lang_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($page)): ?>
            <div class="form-group<?php echo e($errors->has('cntwb_id') ? ' has-error' : ''); ?>">
                <label for="cntwb_id" class="col-sm-2 control-label">Page</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="cntwb_id" value="<?php echo e($page->name); ?>" disabled="">
                    <input type="hidden" name="cntwb_id" value="<?php echo e($page->id); ?>">
                    <input type="hidden" name="cntsec_id" value="<?php echo e($section->id); ?>">
                    <?php if($errors->has('cntwb_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('cntwb_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                <label for="title" class="col-sm-2 control-label">Title</label>
                <div class="col-sm-6">
                    <input id="title" type="text" class="form-control" name="title" value="<?php echo e(!empty($edit_row->title) ? $edit_row->title : old('title')); ?>" autofocus="" placeholder="add title here..">
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('caption') ? ' has-error' : ''); ?>">
                <label for="caption" class="col-sm-2 control-label">Caption</label>
                <div class="col-sm-6">
                    <input id="caption" type="text" class="form-control" name="caption" value="<?php echo e(!empty($edit_row->caption) ? $edit_row->caption : old('caption')); ?>" placeholder="add caption here...">
                    <?php if($errors->has('caption')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('caption')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                <label for="type" class="col-sm-2 control-label">Type</label>
                <div class="col-sm-6">
                    <select name="type" id="type" class="form-control" required="">
                        <option value="">select</option>
                        <option value="page" <?php echo e(!empty($edit_row) && $edit_row->type == 'page' || old('type') == 'page' ? 'selected' : ''); ?>>Page Image</option>
                        <option value="link" <?php echo e(!empty($edit_row) && $edit_row->type == 'link' || old('type') == 'link' ? 'selected' : ''); ?>>Link Image</option>
                        <!-- <option value="content" <?php echo e(!empty($edit_row) && $edit_row->type == 'content' || old('type') == 'content' ? 'selected' : ''); ?>>Content Image</option> -->
                    </select>
                    <?php if($errors->has('type')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('type')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label"></label>
                <div class="col-sm-6 text-danger">
                    If this image link to another page select that from below field
                </div>
            </div>

            <?php if(!empty($pages)): ?>
            <div class="form-group<?php echo e($errors->has('url') ? ' has-error' : ''); ?>">
                <label for="url" class="col-sm-2 control-label">Linked Page</label>
                <div class="col-sm-6">
                    <select name="url" id="url" class="form-control">
                        <option value="">select</option>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($page->slug); ?>" <?php echo e(!empty($edit_row) && $edit_row->url == $page->slug || old('url') == $page->slug ? 'selected' : ''); ?>><?php echo e($page->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('url')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('url')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 text-danger font-md" style="margin-bottom: 10px;">
                    Maximum image size 1mb
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                <label for="image" class="col-sm-2 control-label">Image</label>
                <div class="col-sm-2">
                    <div class="row">
                        <div class="col-sm-12">
                            <input id="image" type="file" accept=".jpg, .png, .gif" name="image" onchange="readURL(this);">
                            <img id="image_preview" src="" alt="" class="img-responsive mt15">
                            <?php if(!empty($edit_row->image)): ?>                                
                            <span class="text-danger"> * Update will delete the old image automatically</span>
                            <?php endif; ?>
                            <script>
                                function readURL(input)
                                {
                                    if (input.files && input.files[0])
                                    {
                                        var reader = new FileReader();
                                        reader.onload = function (e)
                                        {
                                            $('#image_preview')
                                            .attr('src', e.target.result)
                                        };
                                        reader.readAsDataURL(input.files[0]);
                                    }
                                }
                            </script>
                        </div>
                    </div>
                    <?php if($errors->has('image')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('image')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <?php if(!empty($edit_row->image)): ?>
                <label for="old_image" class="col-sm-2 control-label">Old Image</label>
                <div class="col-sm-2">
                    <div class="row">
                        <div class="col-sm-12">
                            <img id="old_image_preview" src="<?php echo e(asset('cntimgSM/'.$edit_row->image)); ?>" alt="" class="img-responsive img-thumbnail mt15">
                            <input type="hidden" name="old_image" value="<?php echo e($edit_row->image); ?>">
                            <input type="checkbox" name="delete_old_image"> Delete Old image <br>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="form-group<?php echo e($errors->has('order_no') ? ' has-error' : ''); ?>">
                <label for="order_no" class="col-sm-2 control-label">Order No</label>
                <div class="col-sm-6">
                    <input id="order_no" type="number" class="form-control" name="order_no" value="<?php echo e(!empty($edit_row->order_no) ? $edit_row->order_no : old('order_no')); ?>" required="">
                    <?php if($errors->has('order_no')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('order_no')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                <label for="status" class="col-sm-2 control-label">Status</label>
                <div class="col-sm-6">
                    <label class="radio-inline"><input type="radio" name="status" value="1" checked="" <?php echo e(!empty($edit_row) && $edit_row->status == 1 ? 'checked' : ''); ?>>Active</label>
                    <label class="radio-inline"><input type="radio" name="status" value="2"  <?php echo e(!empty($edit_row) && $edit_row->status == 2 ? 'checked' : ''); ?>>Inactive</label>
                    <?php if($errors->has('status')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('status')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-6 col-sm-offset-2">
                    <div class="col-sm-6">
                        <div class="row">
                            <button type="submit" class="btn btn-primary btn-block">
                            <?php echo e(!empty($edit_row->id) ?  'Update' : 'Save'); ?>

                        </button>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <input type="reset" class="btn btn-warning btn-block">
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>