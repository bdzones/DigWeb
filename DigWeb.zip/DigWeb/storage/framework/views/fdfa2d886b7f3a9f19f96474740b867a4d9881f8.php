<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-primary">
                <div class="panel-heading text-center"><h2><strong>Edit Website Information</strong></h2></div>
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(!empty($edit_row) ? url('update-web-infos') : url('store-web-infos')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php if(!empty($edit_row)): ?>
                    <?php echo e(method_field('PATCH')); ?>

                    <?php endif; ?>
                    <div class="panel-body">

                        <?php if(!empty($langs)): ?>
                        <div class="form-group<?php echo e($errors->has('lang_id') ? ' has-error' : ''); ?>">
                            <label for="lang_id" class="col-sm-2 control-label">Language</label>
                            <div class="col-sm-6">
                                <select name="lang_id" id="lang_id" class="form-control">
                                    <option value="">select</option>
                                    <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lang->id); ?>" <?php echo e(!empty($edit_row) && $edit_row->lang_id == $lang->id || old('lang_id') == $lang->id ? 'selected' : ''); ?>><?php echo e($lang->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('lang_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lang_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-sm-2 control-label">Website Name</label>
                            <div class="col-sm-8">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(!empty($edit_row->name) ? $edit_row->name : old('name')); ?>" required="" autofocus="">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="col-sm-2 text-danger">Required</div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('subtitle') ? ' has-error' : ''); ?>">
                            <label for="subtitle" class="col-sm-2 control-label">Subtitle</label>
                            <div class="col-sm-8">
                                <input id="subtitle" type="text" class="form-control" name="subtitle" value="<?php echo e(!empty($edit_row->subtitle) ? $edit_row->subtitle : old('subtitle')); ?>">
                                <?php if($errors->has('subtitle')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('subtitle')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-sm-2 control-label">Email</label>
                            <div class="col-sm-8">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(!empty($edit_row->email) ? $edit_row->email : old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('contact_no') ? ' has-error' : ''); ?>">
                            <label for="contact_no" class="col-sm-2 control-label">Contact No</label>
                            <div class="col-sm-8">
                                <input id="contact_no" type="text" class="form-control" name="contact_no" value="<?php echo e(!empty($edit_row->contact_no) ? $edit_row->contact_no : old('contact_no')); ?>">
                                <?php if($errors->has('contact_no')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('contact_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
                            <label for="website" class="col-sm-2 control-label">Website URL</label>
                            <div class="col-sm-8">
                                <input id="website" type="text" class="form-control" name="website" value="<?php echo e(!empty($edit_row->website) ? $edit_row->website : old('website')); ?>">
                                <?php if($errors->has('website')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('website')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('owner') ? ' has-error' : ''); ?>">
                            <label for="owner" class="col-sm-2 control-label">Owner</label>
                            <div class="col-sm-8">
                                <input id="owner" type="text" class="form-control" name="owner" value="<?php echo e(!empty($edit_row->owner) ? $edit_row->owner : old('owner')); ?>">
                                <?php if($errors->has('owner')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('owner')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                            <label for="address" class="col-sm-2 control-label">address</label>
                            <div class="col-sm-8">
                                <textarea name="address" id="address" cols="10" rows="5" class="form-control"><?php echo e(!empty($edit_row->address) ? $edit_row->address : old('address')); ?></textarea>
                                <?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-8 col-sm-offset-2 text-danger font-md" style="margin-bottom: 10px;">
                            Maximum logo size 1mb and ratio should be width*height =1*1
                        </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('logo') ? ' has-error' : ''); ?>">
                            <label for="logo" class="col-sm-2 control-label">Logo</label>
                            <div class="col-sm-2">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <input id="logo" type="file" accept=".jpg, .png, .gif" name="logo" onchange="readURL(this);">
                                        <img id="logo_preview" src="" alt="" class="img-responsive mt15">
                                        <?php if(!empty($edit_row->logo)): ?>                                
                                        <span class="text-danger"> * Update will delete the old Logo automatically</span>
                                        <?php endif; ?>
                                        <script>
                                            function readURL(input)
                                            {
                                                if (input.files && input.files[0])
                                                {
                                                    var reader = new FileReader();
                                                    reader.onload = function (e)
                                                    {
                                                        $('#logo_preview')
                                                        .attr('src', e.target.result)
                                                    };
                                                    reader.readAsDataURL(input.files[0]);
                                                }
                                            }
                                        </script>
                                    </div>
                                </div>
                                <?php if($errors->has('logo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('logo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <?php if(!empty($edit_row->logo)): ?>
                            <label for="old_logo" class="col-sm-2 control-label">Old logo</label>
                            <div class="col-sm-2">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <img id="old_logo_preview" src="<?php echo e(asset('img/'.$edit_row->logo)); ?>" alt="" class="img-responsive img-thumbnail mt15">
                                        <input type="hidden" name="old_logo" value="<?php echo e($edit_row->logo); ?>">
                                        <input type="checkbox" name="delete_old_logo"> Delete Old Logo <br>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('details') ? ' has-error' : ''); ?>">
                            <label for="details" class="col-sm-2 control-label">Details</label>
                            <div class="col-sm-8">
                                <textarea name="details" id="details" class="form-control"><?php echo e(!empty($edit_row->details) ? $edit_row->details : old('details')); ?></textarea>
                                <?php if($errors->has('details')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('details')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(!empty($edit_row->name) ?  'Update' : 'Save'); ?>

                                </button>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>
    CKEDITOR.replace('address');
    CKEDITOR.replace('details');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dboard.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>