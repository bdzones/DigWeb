            <div id="sidebar-wrapper">
                <ul class="sidebar-nav">
                    <?php if(Auth::user() && Auth::user()->type == 'system'): ?>
                    <li class="system-nav">
                        <a href="#system-bar" data-toggle="collapse">System</a>
                        <ul id="system-bar" class="collapse system-bar">
                            <li><a href="<?php echo e(url('all-langs')); ?>">Languages</a></li>
                            <li><a href="<?php echo e(url('web-infos')); ?>">Web Infos</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(url('all-pages')); ?>">Pages</a></li>
                    <li><a href="<?php echo e(url('all-page-contents')); ?>">Page Contents</a></li>
                    <!-- <li><a href="<?php echo e(url('all-texts')); ?>">Texts</a></li>
                    <li><a href="<?php echo e(url('all-images')); ?>">Images</a></li>
                    <li><a href="<?php echo e(url('all-orders')); ?>">Orders</a></li>
                    <li><a href="<?php echo e(url('all-sales')); ?>">Sale Reports</a></li>
                    <li><a href="<?php echo e(url('/all-slides')); ?>">Slide Images</a></li>
                    <li><a href="<?php echo e(url('/all-contents')); ?>">Text Contents</a></li> -->
                </ul>
            </div>