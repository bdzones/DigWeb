	<div class="dbar">
        <div class="row">
            <div class="container">
                <span class="pull-right">
                    <a href="<?php echo e(url('dboard')); ?>" class="btn btn-xs btn-danger">Dashboard</a>
                </span>
            </div>
        </div>
    </div>