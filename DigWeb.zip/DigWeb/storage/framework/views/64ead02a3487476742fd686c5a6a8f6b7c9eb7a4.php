<?php $webInfos = webInfos() ?>
<footer class="container-fluid theme-bg theme-font-color">
	<div class="">
		<div class="container pt15 mt15">
			<a class="pull-right btn-to-top" href="#myPage" title="To Top">
			    <span class="fa fa-chevron-up fa-2x"></span>
			</a>
			<div class="col-sm-12 pb15">
				<div class="row">
					<div class="col-sm-4">
						<div class="row">
							<p class="bold font-md"><a href="<?php echo e(url('/')); ?>" class="theme-font-color"><?php echo e($webInfos->name); ?></a></p>
							<p><i class="fa fa-phone"></i> <?php echo e($webInfos->contact_no); ?></p>
							<p><i class="fa fa-envelope"></i> <?php echo e($webInfos->email); ?></p>
						</div>
					</div>
					<div class="col-sm-4 hidden-xs text-center">
						<a class="" href="<?php echo e(url('/')); ?>"><img class="img-responsive footer-logo" src="<?php echo e(!empty($webInfos->logo) ? asset('img/'.$webInfos->logo) : asset('img/sample_logo.jpg')); ?>" alt="<?php echo e(!empty($webInfos->name) ? $webInfos->name : config('app.name')); ?>" style="max-width: 170px;margin:auto;background-color: rgba(0,0,0, .5); padding: 10px"></a>
					</div>
					<div class="col-sm-4">
						<div class="row">
							<address class="text-right">
								<p class="font-md">Our Address</p>
								<p><?php echo $webInfos->address ?></p>
								
							</address>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-12 pt15">
				<div class="row">
					<p class="text-center">
						<?php echo e(date('Y')); ?> - All Rights Reserved by <a class="theme-font-color" href="<?php echo e(url('/')); ?>"><strong><?php echo e(!empty($webInfos->name) ? $webInfos->name : config('app.name')); ?></strong></a> <i style="color: black;">developed by <a href="http://www.bdzones.com/" target="_blank"><img src="<?php echo e(asset('img/BDZONES.png')); ?>" alt="BDZONES" class="footer-bdzones"></a></i>
					</p>
				</div>
			</div>
		</div>
	</div>
</footer>