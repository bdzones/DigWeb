Application Info
================
Name : Dynamic Web (DigWeb)
Type : Web Content Management System
Framework : Laravel 5.5
Author : Mosharof Hossen

# WebInfo(wbinf)
	all the common informations and the logo in need, the name of the website, title, subtitle, address, gps, email, contact no and etc which are the public informations basically

# WebContent(cntwb)
	all the contents that comes through url like home, about us, contact, products, product-details, categories like women stuffs, menz stuffs, gallery, albums and anything those have unique urls, another fact is that these wil be the menus in the navbar

# ContentSection(cntsec)
	all the sections for a webpage with the types assigned to, this is the most important part of the system of getting essential layout basic prorerties. on 2nd versio it may be used to customized the indvidul layouts for every section.

# TextContent(cnttxt)
	all the text contents those provides any textual contens in the web content pages ike home welcome notice, about us, product details, gallery story, featured speeches or texts and anything those needs text contents in the web pages
	
# ImageContent(cntimg)
	same to the text contents strategy

Database:

System Tables

1. Users
2. Language
2. Profile (if applicable)
3. UserGroup (if applicable)
4. UserLog
5. Division (if applicable)
6. District (if applicable)
7. Thana (if applicable)
8. PostOffice (if applicable)
9. WebInfo

Content Tables

// website //

1. Cntwb
2. Cntsec
3. Cnttxt
4. Cntimg
5. Cntvdo

// application //

7. Dtctg DataCategory
8. Dtitm DataItem 

// configurations //

// blog
5. Post (if applicable for blog)
6. Comments (if applicable for blog)
7. PostImage (if applicable for blog)