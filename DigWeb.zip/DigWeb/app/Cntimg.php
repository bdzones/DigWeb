<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cntimg extends Model
{
    protected $fillable = ['lang_id','cntwb_id','cntsec_id','cnttxt_id','title','caption','type','url','image','order_no','user_id','status'];

    public function lang()
    {
        return $this->belongsTo(Lang::class);
    }

    public function web()
    {
        return $this->belongsTo(Cntwb::class, 'id');
    }

    public function section()
    {
        return $this->belongsTo(Cntsec::class);
    }

    public function text()
    {
    	return $this->belongsTo(Cntwb::class);
    }

    public function user()
    {
    	return $this->belongsTo(User::class);
    }
}