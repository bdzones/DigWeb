<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    protected $fillable = ['lang_id','user_id','full_name','father_name','mother_name','gender','dob','photo','nid','passport_no','contact_no','contact_email','permanent_address','mailing_address','status'];

    public function lang()
    {
    	return $this->belongsTo(Lang::class);
    }

    public function user()
    {
    	return $this->belongsTo(User::class);
    }
}
