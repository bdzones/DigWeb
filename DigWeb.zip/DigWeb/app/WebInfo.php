<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WebInfo extends Model
{
    protected $fillable = ['lang_id','name','subtitle','logo','contact_no','email','website','address','owner','details'];

    public function lang()
    {
    	return $this->belongsTo(Lang::class);
    }
}