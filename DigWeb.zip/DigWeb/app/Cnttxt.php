<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cnttxt extends Model
{
    protected $fillable = ['lang_id','cntwb_id','cntsec_id','title','subtitle','type','order_no','details','image','user_id','status'];

    public function lang()
    {
        return $this->belongsTo(Lang::class);
    }

    public function web()
    {
        return $this->belongsTo(Cntwb::class, 'id');
    }

    public function section()
    {
        return $this->belongsTo(Cntsec::class);
    }

    public function user()
    {
    	return $this->belongsTo(User::class);
    }

    public function images()
    {
    	return $this->belongsTo(Cntimg::class);
    }
}