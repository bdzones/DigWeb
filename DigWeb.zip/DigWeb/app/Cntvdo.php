<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cntvdo extends Model
{
    protected $fillable = ['lang_id','cntwb_id','cntsec_id','cnttxt_id','title','caption','type','image','video_link','order_no','user_id','status'];

    public function lang()
    {
        return $this->belongsTo(Lang::class);
    }

    public function web()
    {
        return $this->belongsTo(Cntwb::class, 'id');
    }

    public function section()
    {
        return $this->belongsTo(Cntsec::class, 'id');
    }

    public function text()
    {
    	return $this->belongsTo(Cntwb::class);
    }

    public function user()
    {
    	return $this->belongsTo(User::class);
    }
}
