<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cntsec extends Model
{
    protected $fillable = ['cntwb_id','title','order_no','type','section_width','content_width','padding','bg_color','text_align','font_color','bg_image','total_column','user_id','status'];
    
    public function user()
    {
    	return $this->belongsTo(User::class);
    }

    public function web()
    {
    	return $this->belongsTo(Cntwb::class);
    }

    public function texts()
    {
    	return $this->hasMany(Cnttxt::class)->where('type','text')->orderBy('order_no','ASC');
    }

    public function articles()
    {
        return $this->hasMany(Cnttxt::class)->where('type','article')->orderBy('order_no','ASC');
    }

    public function images()
    {
    	return $this->hasMany(Cntimg::class)->where('type','!=','slide')->orderBy('order_no','ASC');
    }

    public function slides()
    {
        return $this->hasMany(Cntimg::class)->where('type','slide')->orderBy('order_no','ASC');
    }

    /*public function link_images()
    {
        return $this->hasMany(Cntimg::class)->where('type','link')->orderBy('order_no','ASC');
    }

    public function content_images()
    {
        return $this->hasMany(Cntimg::class)->where('type','content')->orderBy('order_no','ASC');
    }*/

    public function videos()
    {
    	return $this->hasMany(Cntvdo::class)->where('type','content')->orderBy('order_no','ASC');
    }
}
