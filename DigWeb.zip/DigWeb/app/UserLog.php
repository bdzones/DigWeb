<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserLog extends Model
{
    protected $fillable = ['user_id','activities','device','ip_address','browser','localtime','gps','login_time','logout_time'];

    public function user()
    {
    	return $this->belongsTo(User::class);
    }
}
