<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lang extends Model
{
    protected $fillable = ['name','code_2f','code_3f','type','status'];

    // this is a common model that helps rest of the model to switch language

    public function webs()
    {
    	return $this->hasMany(Cntwb::class);
    }

    public function texts()
    {
    	return $this->hasMany(Cnttxt::class);
    }

    public function images()
    {
    	return $this->hasMany(Cntimg::class);
    }

    public function web_infos()
    {
    	return $this->hasMany(WebInfo::class);
    }

    public function profiles()
    {
    	return $this->hasMany(Profile::class);
    }
}
