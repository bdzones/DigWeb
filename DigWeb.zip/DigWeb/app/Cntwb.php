<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cntwb extends Model
{
    protected $fillable = ['lang_id','parent_id','name',',slug','type','order_no','fa_icon','meta_title','meta_details','width','bg_color','bg_image','user_id','status'];

    public function lang()
    {
        return $this->belongsTo(Lang::class);
    }

    public function user()
    {
    	return $this->belongsTo(User::class);
    }

    public function parent()
    {
        return $this->belongsTo(self::class, 'parent_id')->orderBy('order_no','ASC');
    }

    public function children()
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('order_no','ASC');
    }

    public function sections()
    {
    	return $this->hasMany(Cntsec::class)->orderBy('order_no','ASC');
    }

    public function texts()
    {
        return $this->hasMany(Cnttxt::class)->orderBy('order_no','ASC');
    }

    public function images()
    {
    	return $this->hasMany(Cntimg::class)->orderBy('order_no','ASC');
    }
}