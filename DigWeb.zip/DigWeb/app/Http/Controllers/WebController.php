<?php

namespace App\Http\Controllers;

use App\Cntwb;

use Illuminate\Http\Request;

class WebController extends Controller
{
    public function index()
    {
        $check_page = Cntwb::get();
        if(count($check_page) > 0 ){
            return redirect('page/home');
        }else{
            return view('home');
        }
        
    }

    public function page($slug)
    {
    	$page = Cntwb::with('sections')->where('slug',$slug)->where('status',1)->first();
        //return $page;
    	return view('web.page',compact('page'));
    }
}
