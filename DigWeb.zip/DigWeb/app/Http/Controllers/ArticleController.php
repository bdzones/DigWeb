<?php

namespace App\Http\Controllers;

use Auth;
use App\Lang;
use App\Cntwb;
use App\Cntsec;
use App\Cnttxt;
use App\Cntimg;
use App\WebInfo;

use Image;
use Storage;

use Illuminate\Http\Request;

class ArticleController extends Controller
{
    // article
    public function add_article($id)
    {
        $section = Cntsec::find($id);
        $langs = Lang::select('id','name')->where('status',1)->get();
        $page = Cntwb::select('id','name')->find($section->cntwb_id);
        $edit_row = "";
        return view('dboard.add_article',compact('edit_row','page','langs','section'));
    }

    public function store_article(Request $request)
    {
        $this->validate($request, [
            'cntwb_id' => 'required',
            'title' => 'required',
            'details' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $articles = new Cnttxt;
        $articles->lang_id = $request->lang_id;
        $articles->cntwb_id = $request->cntwb_id;
        $articles->cntsec_id = $request->cntsec_id;
        $articles->title = $request->title;
        $articles->subtitle = $request->subtitle;
        $articles->type = 'article';
        $articles->order_no = $request->order_no;
        $articles->details = $request->details;
        $articles->user_id = Auth::user()->id;
        $articles->status = $request->status ? $request->status : 1 ;

        if($request->hasFile('image')){

            $fileSize = $request->file('image')->getClientSize();

            if ($fileSize > 1024000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }

            $image = $request->file('image');

            // rename image following the item name
            $imageName = str_replace(' ', '_', $request->title).date('Y_m_d_h_i_s').'.'.$image->getClientOriginalExtension();

            // upload large image with resize 1200 * aspect-ratio
            $imageFile = Image::make($request->file('image'));
            $imageFile->resize(1000, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFile = Storage::disk('cntimgs')->put($imageName, $imageFile);
            // upload small image with resize 300 * aspect-ratio
            $imageFileSM = Image::make($request->file('image'));
            $imageFileSM->resize(300, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFileSM = Storage::disk('cntimgSM')->put($imageName, $imageFileSM);

            $articles->image = $imageName;
        }

        $articles->save();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function edit_article($id)
    {
        $langs = Lang::select('id','name')->where('status',1)->get();
        $pages = Cntwb::select('id','name')->where('type','webpage')->where('status',1)->get();
        $edit_row = Cnttxt::find($id);
        return view('dboard.add_article',compact('edit_row','pages','langs'));
    }

    public function update_article(Request $request, $id)
    {
        $this->validate($request, [
            'cntwb_id' => 'required',
            'title' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $articles = Cnttxt::find($id);
        $articles->lang_id = $request->lang_id;
        $articles->cntwb_id = $request->cntwb_id;
        $articles->title = $request->title;
        $articles->subtitle = $request->subtitle;
        $articles->type = $request->type;
        $articles->order_no = $request->order_no;
        $articles->details = $request->details;
        $articles->user_id = Auth::user()->id;
        $articles->status = $request->status;

        // manually delete image
        if($request->delete_old_image == 'on'){
            
            // check existing file and delete before update new one
            if(file_exists(public_path().'/cntimgs/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgs/'.$request->old_image);
            }
            if(file_exists(public_path().'/cntimgSM/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgSM/'.$request->old_image);
            }

            $articles->image = "";
        }

        if($request->hasFile('image')){

            $fileSize = $request->file('image')->getClientSize();

            if ($fileSize > 1024000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }

            // check existing file and delete before update new one
            if(file_exists(public_path().'/cntimgs/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgs/'.$request->old_image);
            }
            if(file_exists(public_path().'/cntimgSM/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgSM/'.$request->old_image);
            }
            // update image
            $image = $request->file('image');
            // rename image following the item name
            $imageName = str_replace(' ', '_', $request->title).date('Y_m_d_h_i_s').'.'.$image->getClientOriginalExtension();

            // upload large image with resize 1200 * aspect-ratio
            $imageFile = Image::make($request->file('image'));
            $imageFile->resize(1000, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFile = Storage::disk('cntimgs')->put($imageName, $imageFile);
            // upload small image with resize 300 * aspect-ratio
            $imageFileSM = Image::make($request->file('image'));
            $imageFileSM->resize(300, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFileSM = Storage::disk('cntimgsSm')->put($imageName, $imageFileSM);

            $articles->image = $imageName;
        }

        $articles->update();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function delete_article($id)
    {
        $articles = Cnttxt::find($id);
        // check existing file and delete before update new one
        if(file_exists(public_path().'/cntimgs/'.$request->old_image) == 1){
                unlink(public_path().'/cntimgs/'.$request->old_image);
        }
        if(file_exists(public_path().'/cntimgSM/'.$request->old_image) == 1){
                unlink(public_path().'/cntimgSM/'.$request->old_image);
        }

        $articles->delete();

        return redirect('all-articles');
    }
}
