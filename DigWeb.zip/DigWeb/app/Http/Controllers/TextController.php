<?php

namespace App\Http\Controllers;

use Auth;
use App\Lang;
use App\Cntwb;
use App\Cntsec;
use App\Cnttxt;
use App\Cntimg;
use App\WebInfo;

use Illuminate\Http\Request;

class TextController extends Controller
{
    // text contents
    public function all_texts()
    {
        $texts = Cnttxt::with('lang')->with('web')->paginate(20);
        return view('dboard.text_contents',compact('texts'));
    }

    public function add_text($id)
    {
        $section = Cntsec::find($id);
        $langs = Lang::select('id','name')->where('status',1)->get();
        $page = Cntwb::select('id','name')->find($section->cntwb_id);
        $edit_row = "";
        return view('dboard.add_text',compact('edit_row','page','langs','section'));
    }

    public function store_text(Request $request)
    {
        $this->validate($request, [
            //'title' => 'required',
            'details' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $texts = new Cnttxt;
        $texts->lang_id = $request->lang_id;
        $texts->cntwb_id = $request->cntwb_id;
        $texts->cntsec_id = $request->cntsec_id;
        $texts->title = $request->title;
        $texts->subtitle = $request->subtitle;
        $texts->type = 'text';
        $texts->order_no = $request->order_no;
        $texts->details = $request->details;
        $texts->user_id = Auth::user()->id;
        $texts->status = $request->status ? $request->status : 1 ;
        $texts->save();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function edit_text($id)
    {
        $edit_row = Cnttxt::find($id);
        $section = Cntsec::find($edit_row->cntsec_id);
        $langs = Lang::select('id','name')->where('status',1)->get();
        $page = Cntwb::select('id','name')->find($section->cntwb_id);
        return view('dboard.add_text',compact('edit_row','page','langs','section'));
    }

    public function update_text(Request $request, $id)
    {
        $this->validate($request, [
            //'title' => 'required',
            'details' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $texts = Cnttxt::find($id);
        $texts->lang_id = $request->lang_id;
        $texts->cntwb_id = $request->cntwb_id;
        $texts->cntsec_id = $request->cntsec_id;
        $texts->title = $request->title;
        $texts->subtitle = $request->subtitle;
        $texts->type = 'text';
        $texts->order_no = $request->order_no;
        $texts->details = $request->details;
        $texts->user_id = Auth::user()->id;
        $texts->status = $request->status ? $request->status : 1 ;
        $texts->update();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function delete_text($id)
    {
        $texts = Cnttxt::find($id);

        $texts->delete();

        return back();
    }
}
