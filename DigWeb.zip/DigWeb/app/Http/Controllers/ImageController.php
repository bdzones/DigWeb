<?php

namespace App\Http\Controllers;

use Auth;
use App\Lang;
use App\Cntwb;
use App\Cntsec;
use App\Cnttxt;
use App\Cntimg;
use App\WebInfo;

use Image;
use Storage;

use Illuminate\Http\Request;

class ImageController extends Controller
{
    // image content
    public function all_images()
    {
        $images = CntImg::with('lang')->with('web')->paginate(20);
        return view('dboard.image_contents');
    }

    public function add_image($id)
    {
        $pages = Cntwb::select('id','name','slug')->where('status',1)->get();
        $section = Cntsec::find($id);
        $langs = Lang::select('id','name')->where('status',1)->get();
        $page = Cntwb::select('id','name')->find($section->cntwb_id);
        $edit_row = "";

        return view('dboard.add_image',compact('edit_row','page','langs','section','pages'));
    }

    public function store_image(Request $request)
    {
        $this->validate($request,[
            'cntwb_id' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $images = new Cntimg;
        $images->lang_id = $request->lang_id;
        $images->cntwb_id = $request->cntwb_id;
        $images->cntsec_id = $request->cntsec_id;
        $images->cnttxt_id = $request->cnttxt_id;
        $images->title = $request->title;
        $images->caption = $request->caption;
        $images->type = $request->type;
        $images->url = $request->url;
        $images->order_no = $request->order_no;
        $images->user_id = Auth::user()->id;
        $images->status = $request->status ? $request->status : 1 ;

        if($request->hasFile('image')){

            $fileSize = $request->file('image')->getClientSize();

            if ($fileSize > 1024000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }

            $image = $request->file('image');

            // rename image following the item name
            $imageName = str_replace(' ', '_', $request->title).date('Y_m_d_h_i_s').'.'.$image->getClientOriginalExtension();

            // upload large image with resize 1200 * aspect-ratio
            $imageFile = Image::make($request->file('image'));
            $imageFile->resize(1000, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFile = Storage::disk('cntimgs')->put($imageName, $imageFile);
            // upload small image with resize 300 * aspect-ratio
            $imageFileSM = Image::make($request->file('image'));
            $imageFileSM->resize(300, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFileSM = Storage::disk('cntimgSM')->put($imageName, $imageFileSM);

            $images->image = $imageName;
        }

        $images->save();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function edit_image($id)
    {
        $edit_row = Cntimg::find($id);
        $pages = Cntwb::select('id','name','slug')->where('status',1)->get();
        $section = Cntsec::find($edit_row->cntsec_id);
        $langs = Lang::select('id','name')->where('status',1)->get();
        $page = Cntwb::select('id','name')->find($section->cntwb_id);

        return view('dboard.add_image',compact('edit_row','page','langs','section','pages'));
    }

    public function update_image(Request $request, $id)
    {
        $this->validate($request,[
            'cntwb_id' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $images = Cntimg::find($id);
        $images->lang_id = $request->lang_id;
        $images->cntwb_id = $request->cntwb_id;
        $images->cnttxt_id = $request->cnttxt_id;
        $images->title = $request->title;
        $images->caption = $request->caption;
        $images->type = $request->type;
        $images->url = $request->url;
        $images->order_no = $request->order_no;
        $images->user_id = Auth::user()->id;
        $images->status = $request->status;

        // manually delete image
        if($request->delete_old_image == 'on'){
            
            // check existing file and delete before update new one
            if(file_exists(public_path().'/cntimgs/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgs/'.$request->old_image);
            }
            if(file_exists(public_path().'/cntimgSM/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgSM/'.$request->old_image);
            }

            $images->image = "";
        }

        if($request->hasFile('image')){

            $fileSize = $request->file('image')->getClientSize();

            if ($fileSize > 1024000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }

            // check existing file and delete before update new one
            if(!empty($request->old_image)){
            	if(file_exists(public_path().'/cntimgs/'.$request->old_image) == 1){
	                    unlink(public_path().'/cntimgs/'.$request->old_image);
	            }
	            if(file_exists(public_path().'/cntimgSM/'.$request->old_image) == 1){
	                    unlink(public_path().'/cntimgSM/'.$request->old_image);
	            }
            }
            // update image
            $image = $request->file('image');
            // rename image following the item name
            $imageName = str_replace(' ', '_', $request->title).date('Y_m_d_h_i_s').'.'.$image->getClientOriginalExtension();

            // upload large image with resize 1200 * aspect-ratio
            $imageFile = Image::make($request->file('image'));
            $imageFile->resize(1000, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFile = Storage::disk('cntimgs')->put($imageName, $imageFile);
            // upload small image with resize 300 * aspect-ratio
            $imageFileSM = Image::make($request->file('image'));
            $imageFileSM->resize(300, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFileSM = Storage::disk('cntimgSM')->put($imageName, $imageFileSM);

            $images->image = $imageName;
        }

        $images->update();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function delete_image($id)
    {
        $images = CntImg::find($id);

        // check existing file and delete before update new one
        if(file_exists(public_path().'/cntimgs/'.$images->image) == 1){
            unlink(public_path().'/cntimgs/'.$images->image);
        }
        if(file_exists(public_path().'/cntimgSM/'.$images->image) == 1){
            unlink(public_path().'/cntimgSM/'.$images->image);
        }

        $images->delete();

        return redirect('all-page-contents');
    }

    // slide
    public function add_slide($id)
    {
        $pages = Cntwb::select('id','name','slug')->where('status',1)->get();
        $section = Cntsec::find($id);
        $langs = Lang::select('id','name')->where('status',1)->get();
        $page = Cntwb::select('id','name')->find($section->cntwb_id);
        $edit_row = "";
        
        return view('dboard.add_slide',compact('edit_row','page','langs','section','pages'));
    }

    public function store_slide(Request $request)
    {
        $this->validate($request,[
            'cntwb_id' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $slides = new Cntimg;
        $slides->lang_id = $request->lang_id;
        $slides->cntwb_id = $request->cntwb_id;
        $slides->cntsec_id = $request->cntsec_id;
        $slides->cnttxt_id = $request->cnttxt_id;
        $slides->title = $request->title;
        $slides->caption = $request->caption;
        $slides->type = 'slide';
        $slides->order_no = $request->order_no;
        $slides->user_id = Auth::user()->id;
        $slides->status = $request->status ? $request->status : 1 ;

        if($request->hasFile('image')){

            $fileSize = $request->file('image')->getClientSize();

            if ($fileSize > 1024000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }

            $slide = $request->file('image');

            // rename slide following the item name
            $slideName = str_replace(' ', '_', $request->title).date('Y_m_d_h_i_s').'.'.$slide->getClientOriginalExtension();

            // upload large slide with resize 1200 * aspect-ratio
            $slideFile = Image::make($request->file('image'));
            $slideFile->resize(1000, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFile = Storage::disk('cntimgs')->put($slideName, $slideFile);
            // upload small slide with resize 300 * aspect-ratio
            $slideFileSM = Image::make($request->file('image'));
            $slideFileSM->resize(300, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFileSM = Storage::disk('cntimgSM')->put($slideName, $slideFileSM);

            $slides->image = $slideName;
        }

        $slides->save();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function edit_slide($id)
    {
        $edit_row = Cntimg::find($id);
        $pages = Cntwb::select('id','name','slug')->where('status',1)->get();
        $section = Cntsec::find($edit_row->cntsec_id);
        $langs = Lang::select('id','name')->where('status',1)->get();
        $page = Cntwb::select('id','name')->find($section->cntwb_id);

        return view('dboard.add_slide',compact('edit_row','page','langs','section','pages'));
    }

    public function update_slide(Request $request, $id)
    {
        $this->validate($request,[
            'cntwb_id' => 'required',
            'image' => 'mimes:jpeg,bmp,png',
        ]);

        $slides = Cntimg::find($id);
        $slides->lang_id = $request->lang_id;
        $slides->cntwb_id = $request->cntwb_id;
        $slides->cnttxt_id = $request->cnttxt_id;
        $slides->title = $request->title;
        $slides->caption = $request->caption;
        $slides->type = 'slide';
        $slides->order_no = $request->order_no;
        $slides->user_id = Auth::user()->id;
        $slides->status = $request->status;

        // manually delete slide
        if($request->delete_old_image == 'on'){
            
            // check existing file and delete before update new one
            if(file_exists(public_path().'/cntimgs/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgs/'.$request->old_image);
            }
            if(file_exists(public_path().'/cntimgSM/'.$request->old_image) == 1){
                    unlink(public_path().'/cntimgSM/'.$request->old_image);
            }

            $slides->image = "";
        }

        if($request->hasFile('image')){

            $fileSize = $request->file('image')->getClientSize();

            if ($fileSize > 1024000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }

            // check existing file and delete before update new one
            if(!empty($request->old_image)){
                if(file_exists(public_path().'/cntimgs/'.$request->old_image) == 1){
                        unlink(public_path().'/cntimgs/'.$request->old_image);
                }
                if(file_exists(public_path().'/cntimgSM/'.$request->old_image) == 1){
                        unlink(public_path().'/cntimgSM/'.$request->old_image);
                }
            }
            // update slide
            $slide = $request->file('image');
            // rename slide following the item name
            $slideName = str_replace(' ', '_', $request->title).date('Y_m_d_h_i_s').'.'.$slide->getClientOriginalExtension();

            // upload large slide with resize 1200 * aspect-ratio
            $slideFile = Image::make($request->file('image'));
            $slideFile->resize(1000, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFile = Storage::disk('cntimgs')->put($slideName, $slideFile);
            // upload small slide with resize 300 * aspect-ratio
            $slideFileSM = Image::make($request->file('image'));
            $slideFileSM->resize(300, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
            $uploadedFileSM = Storage::disk('cntimgSM')->put($slideName, $slideFileSM);

            $slides->image = $slideName;
        }

        $slides->update();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function delete_slide($id)
    {
        $slides = CntImg::find($id);

        // check existing file and delete before update new one
        if(file_exists(public_path().'/cntimgs/'.$slides->image) == 1){
            unlink(public_path().'/cntimgs/'.$slides->image);
        }
        if(file_exists(public_path().'/cntimgSM/'.$slides->image) == 1){
            unlink(public_path().'/cntimgSM/'.$slides->image);
        }

        $slides->delete();

        return redirect('all-page-contents');
    }
}
