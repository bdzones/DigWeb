<?php

namespace App\Http\Controllers;

use Auth;
use App\Lang;
use App\Cntwb;
use App\Cntsec;
use App\Cnttxt;
use App\Cntimg;
use App\WebInfo;

use Image;
use Storage;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function dboard()
    {
        return view('dboard.dboard');
    }

    // all page contents
    public function all_pages()
    {
        $pages = Cntwb::with('lang')->with('parent')->whereIn('status',[1,2])->get();
        //return $pages;
        return view('dboard.pages',compact('pages'));
    }

    public function add_page()
    {
        $langs = Lang::select('id','name')->where('status',1)->get();
        $parents = Cntwb::select('id','name')->where('status',1)->get();
        empty($parents) ? $parents = "" : '' ;
        $edit_row = "";
        return view('dboard.add_page',compact('edit_row','parents','langs'));
    }

    public function store_page(Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
            'type' => 'required',
            'order_no' => 'required',
        ]);

        $pages = new Cntwb;
        $pages->lang_id = $request->lang_id;
        $pages->parent_id = $request->parent_id;
        $pages->name = $request->name;
        $pages->slug = $request->type == 'webpage' ? str_slug($request->name,'-') : '' ;
        $pages->type = $request->type;
        $pages->order_no = $request->order_no;
        $pages->fa_icon = $request->fa_icon;
        $pages->meta_title = $request->meta_title;
        $pages->meta_details = $request->meta_details;
        $pages->user_id = Auth::user()->id;
        $pages->status = $request->status ? $request->status : 1 ;
        $pages->save();

        return redirect('all-pages');
    }

    public function edit_page($id)
    {
        $langs = Lang::select('id','name')->where('status',1)->get();
        $parents = Cntwb::select('id','name')->where('status',1)->get();
        empty($parents) ? $parents = "" : '' ;
        $edit_row = Cntwb::find($id);
        return view('dboard.add_page',compact('edit_row','parents','langs'));
    }

    public function update_page(Request $request, $id)
    {
        $this->validate($request,[
            'name' => 'required',
            /*'type' => 'required',
            'order_no' => 'required',*/
        ]);

        $pages = Cntwb::find($id);
        $pages->lang_id = $request->lang_id;
        $pages->parent_id = $request->parent_id;
        $pages->name = $request->name;
        $pages->slug = $request->type == 'webpage' ? str_slug($request->name,'-') : '' ;
        $pages->type = $request->type;
        $pages->order_no = $request->order_no;
        $pages->fa_icon = $request->fa_icon;
        $pages->meta_title = $request->meta_title;
        $pages->meta_details = $request->meta_details;
        $pages->user_id = Auth::user()->id;
        $pages->status = $request->status;
        $pages->update();

        return redirect('all-pages');
    }

    public function delete_page($id)
    {
        $pages = Cntwb::find($id);

        $pages->status = 3;
        $pages->update();

        return redirect('all-pages');
    }

    // page contents/sections
    public function all_page_contents()
    {
        $pages = Cntwb::select('id','parent_id','name','slug','fa_icon')->with('children')->with('sections')->where('status',1)->orderBy('order_no','ASC')->get();
        return view('dboard.page_contents',compact('pages'));
    }

    public function web_infos()
    {
        $web_infos = WebInfo::find(1);
        return view('dboard.web_infos',compact('web_infos'));
    }

    public function edit_web_infos()
    {
        $web_infos = WebInfo::where('id',1)->get();

        if(!empty($web_infos)){
            $edit_row = WebInfo::find(1);
        }else{
            $edit_row = "";
        }

        return view('dboard.edit_web_infos',compact('edit_row'));
    }

    public function update_web_infos(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            /*'subtitle' => 'required',
            'contact_no' => 'required',
            'email' => 'required',
            'website' => 'required',
            'address' => 'required',
            'logo' => 'mimes:jpeg,bmp,png',*/
        ]);

        $web_infos = WebInfo::find(1);
        $web_infos->lang_id = $request->lang_id;
        $web_infos->name = $request->name;
        $web_infos->subtitle = $request->subtitle;
        $web_infos->contact_no = $request->contact_no;
        $web_infos->email = $request->email;
        $web_infos->website = $request->website;
        $web_infos->address = $request->address;
        $web_infos->details = $request->details;
        $web_infos->owner = $request->owner;

        // manually delete image
        if($request->delete_old_logo == 'on'){
            
            // check existing file and delete before update new one
            if(file_exists(public_path().'/img/'.$request->old_logo) == 1){
                    unlink(public_path().'/img/'.$request->old_logo);
            }

            $web_infos->logo = "";
        }

        if($request->hasFile('logo')){

            $fileSize = $request->file('logo')->getClientSize();

            if ($fileSize > 1024000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }

            $image = $request->file('logo');

            // check existing file and delete before update new one
            if(!empty($request->old_logo))
            {
                if(file_exists(public_path().'/img/'.$request->old_logo)){
                        unlink(public_path().'/img/'.$request->old_logo);
                }
            }

            // rename image following the item name
            $imageName = date('Y_m_d_h_i_s').'.'.$image->getClientOriginalExtension();

            // upload large image with resize 1200 * aspect-ratio
            $imageFile = Image::make($request->file('logo'));
            //$imageFile->resize(160, 160)->stream();
            $imageFile->stream();
            $uploadedFile = Storage::disk('img')->put($imageName, $imageFile);

            $web_infos->logo = $imageName;
        }

        $web_infos->update();

        return redirect('web-infos');

    }
}
