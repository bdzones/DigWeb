<?php

namespace App\Http\Controllers;

use Auth;
use App\Lang;
use App\Cntwb;
use App\Cntsec;
use App\Cnttxt;
use App\Cntimg;

use Illuminate\Http\Request;

class SectionController extends Controller
{
    public function add_section($id)
    {
        $edit_row = "";
        $page = Cntwb::select('id','name')->find($id);

        return view('dboard.add_section',compact('edit_row','page'));
    }

    public function store_section(Request $request)
    {
        $this->validate($request,[
            'type' => 'required',
            //'total_column' => 'required',
            'order_no' => 'required',
        ]);

        $sections = new Cntsec;
        $sections->cntwb_id = $request->cntwb_id;
        $sections->type = $request->type;
        $sections->bg_color = $request->bg_color;
        $sections->font_color = $request->font_color;
        $sections->text_align = $request->text_align;
        $sections->section_width = $request->section_width;
        $sections->content_width = $request->content_width;
        $sections->title = $request->title;
        $sections->padding = $request->padding;
        $sections->total_column = $request->total_column ? $request->total_column : 1 ;
        $sections->order_no = $request->order_no;
        $sections->user_id = Auth::user()->id;
        $sections->save();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function edit_section($id)
    {
        $edit_row = Cntsec::find($id);
        $page = Cntwb::select('id','name')->find($edit_row->cntwb_id);

        return view('dboard.add_section',compact('edit_row','page'));
    }

    public function update_section(Request $request, $id)
    {
        $this->validate($request,[
            'type' => 'required',
            //'total_column' => 'required',
            'order_no' => 'required',
        ]);

        $sections = Cntsec::find($id);
        $sections->cntwb_id = $request->cntwb_id;
        $sections->type = $request->type;
        $sections->bg_color = $request->bg_color;
        $sections->font_color = $request->font_color;
        $sections->text_align = $request->text_align;
        $sections->section_width = $request->section_width;
        $sections->content_width = $request->content_width;
        $sections->title = $request->title;
        $sections->padding = $request->padding;
        $sections->total_column = $request->total_column;
        $sections->order_no = $request->order_no;
        $sections->user_id = Auth::user()->id;
        $sections->update();

        $page_info = Cntwb::with('sections')->find($request->cntwb_id);

        return redirect('all-page-contents')->with('page_info',$page_info);
    }

    public function delete_section($id)
    {
        $sections = Cntsec::find($id);
        // delete texts content releted to this section
        $check_texts = Cnttxt::with('section')->where('cntsec_id',$id)->get();
        //return $check_texts;

        if(!empty($check_texts)){
            foreach ($check_texts as $texts) {
                $text = Cnttxt::find($texts->id);
                if(!empty($text->image)){
                    // check existing file and delete before update new one
                    if(file_exists(public_path().'/TxtImg/'.$text->image) == 1){
                            unlink(public_path().'/TxtImg/'.$text->image);
                    }
                    if(file_exists(public_path().'/TxtImg/TxtImgSm/'.$text->image) == 1){
                            unlink(public_path().'/TxtImg/TxtImgSm/'.$text->image);
                    }
                }
                $text->delete();
            }
        }

        // delete images content releted to this section
        $check_images = Cntimg::where('cntsec_id',$id)->get();

        if(!empty($check_images)){
            foreach ($check_images as $images) {
                $image = Cntimg::find($images->id);
                // check existing file and delete before update new one
                if(!empty($image->image)){
                    if(file_exists(public_path().'/CntImg/'.$image->image) == 1){
                            unlink(public_path().'/CntImg/'.$image->image);
                    }
                    if(file_exists(public_path().'/CntImg/CntImgSm/'.$image->image) == 1){
                            unlink(public_path().'/CntImg/CntImgSm/'.$image->image);
                    }
                }
                    
                $image->delete();
            }
        }

        $sections->delete();

        return back();
    }

    // all languages
    public function all_langs()
    {
        $langs = Lang::get();
        return view('dboard.langs',compact('langs'));
    }

    public function add_lang()
    {
        $langs = Lang::select('id','name')->where('status',1)->get();
        $edit_row = "";
        return view('dboard.add_lang',compact('edit_row','langs'));
    }

    public function store_lang(Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
        ]);

        $langs = new Lang;
        $langs->name = $request->name;
        $langs->code_2f = $request->code_2f;
        $langs->code_3f = $request->code_3f;
        $langs->type = $request->type;
        $langs->status = $request->status ? $request->status : 1 ;
        $langs->save();

        return redirect('all-langs');
    }

    public function edit_lang($id)
    {
        $langs = Lang::select('id','name')->where('status',1)->get();
        $edit_row = Lang::find($id);
        return view('dboard.add_lang',compact('edit_row','langs'));
    }

    public function update_lang(Request $request, $id)
    {
        $this->validate($request,[
            'name' => 'required',
        ]);

        $langs = Lang::find($id);
        $langs->name = $request->name;
        $langs->code_2f = $request->code_2f;
        $langs->code_3f = $request->code_3f;
        $langs->type = $request->type;
        $langs->status = $request->status ? $request->status : 1 ;
        $langs->update();

        return redirect('all-langs');
    }
    
    // language should not be deleted
    /*public function delete_lang($id)
    {
        $langs = Lang::find($id);
        $langs->delete();
        
        return redirect('all-langs');
    }*/
}
