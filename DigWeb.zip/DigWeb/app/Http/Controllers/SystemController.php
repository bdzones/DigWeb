<?php

namespace App\Http\Controllers;

use Auth;
use App\Lang;
use App\WebInfo;

use Image;
use Storage;

use Illuminate\Http\Request;

class SystemController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function web_infos()
    {
    	return view('dboard.web_infos');
    }

    public function add_web_infos()
    {
        $langs = Lang::select('id','name')->where('status',1)->get();
    	$edit_row = "";
    	return view('dboard.edit_web_infos',compact('edit_row','langs'));
    }

    public function store_web_infos(Request $request)
    {
    	$this->validate($request, [
    		//'lang_id' => 'required',
            'name' => 'required',
    		/*'subtitle' => 'required',
    		'contact_no' => 'required',
    		'email' => 'required',
    		'website' => 'required',
    		'address' => 'required',
    		'logo' => 'required|mimes:jpeg,bmp,png',*/
    	]);

    	$web_infos = new WebInfo;
    	$web_infos->lang_id = $request->lang_id;
    	$web_infos->name = $request->name;
    	$web_infos->subtitle = $request->subtitle;
    	$web_infos->contact_no = $request->contact_no;
    	$web_infos->email = $request->email;
    	$web_infos->website = $request->website;
        $web_infos->address = $request->address;
        $web_infos->details = $request->details;
        $web_infos->owner = $request->owner;

        if($request->hasFile('logo')){

            $fileSize = $request->file('logo')->getClientSize();

            /*if ($fileSize > 612000) {
                return back()->with('message', 'Too large file (max limit:1mb)');
            }*/

            $image = $request->file('logo');

            // rename image following the item name
            $imageName = date('Y_m_d_h_i_s').'.'.$image->getClientOriginalExtension();

            // upload large image with resize 1200 * aspect-ratio
            $imageFile = Image::make($request->file('logo'));
            //$imageFile->resize(160, 160)->stream();
            $imageFile->stream();
            $uploadedFile = Storage::disk('img')->put($imageName, $imageFile);

            $web_infos->logo = $imageName;
        }

    	$web_infos->save();

    	return redirect('web-infos');
    }
}
