<?php
// website general/public information
function webInfos()
{
	$webInfo = App\WebInfo::find(1);
	return $webInfo;
}
// generate dynamic menus
function menuArray()
{
	$menuArray = array();
	foreach (App\Cntwb::select('id','parent_id','name','slug','fa_icon','meta_title','meta_details')->with('children')->where('status',1)->orderBy('order_no','ASC')->get() as $menus)
	{
		$menuArray[] = $menus;
	}

	return $menuArray;
}