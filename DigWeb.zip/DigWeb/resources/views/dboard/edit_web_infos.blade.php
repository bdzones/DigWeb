@extends('dboard.index')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-primary">
                <div class="panel-heading text-center"><h2><strong>Edit Website Information</strong></h2></div>
                <form class="form-horizontal" role="form" method="POST" action="{{ !empty($edit_row) ? url('update-web-infos') : url('store-web-infos') }}" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    @if(!empty($edit_row))
                    {{ method_field('PATCH') }}
                    @endif
                    <div class="panel-body">

                        @if(!empty($langs))
                        <div class="form-group{{ $errors->has('lang_id') ? ' has-error' : '' }}">
                            <label for="lang_id" class="col-sm-2 control-label">Language</label>
                            <div class="col-sm-6">
                                <select name="lang_id" id="lang_id" class="form-control">
                                    <option value="">select</option>
                                    @foreach ($langs as $key => $lang)
                                    <option value="{{ $lang->id }}" {{ !empty($edit_row) && $edit_row->lang_id == $lang->id || old('lang_id') == $lang->id ? 'selected' : '' }}>{{ $lang->name }}</option>
                                    @endforeach
                                </select>
                                @if ($errors->has('lang_id'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('lang_id') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        @endif
                    
                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-sm-2 control-label">Website Name</label>
                            <div class="col-sm-8">
                                <input id="name" type="text" class="form-control" name="name" value="{{ !empty($edit_row->name) ? $edit_row->name : old('name') }}" required="" autofocus="">
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-sm-2 text-danger">Required</div>
                        </div>

                        <div class="form-group{{ $errors->has('subtitle') ? ' has-error' : '' }}">
                            <label for="subtitle" class="col-sm-2 control-label">Subtitle</label>
                            <div class="col-sm-8">
                                <input id="subtitle" type="text" class="form-control" name="subtitle" value="{{ !empty($edit_row->subtitle) ? $edit_row->subtitle : old('subtitle') }}">
                                @if ($errors->has('subtitle'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('subtitle') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-sm-2 control-label">Email</label>
                            <div class="col-sm-8">
                                <input id="email" type="email" class="form-control" name="email" value="{{ !empty($edit_row->email) ? $edit_row->email : old('email') }}">
                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('contact_no') ? ' has-error' : '' }}">
                            <label for="contact_no" class="col-sm-2 control-label">Contact No</label>
                            <div class="col-sm-8">
                                <input id="contact_no" type="text" class="form-control" name="contact_no" value="{{ !empty($edit_row->contact_no) ? $edit_row->contact_no : old('contact_no') }}">
                                @if ($errors->has('contact_no'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('contact_no') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('website') ? ' has-error' : '' }}">
                            <label for="website" class="col-sm-2 control-label">Website URL</label>
                            <div class="col-sm-8">
                                <input id="website" type="text" class="form-control" name="website" value="{{ !empty($edit_row->website) ? $edit_row->website : old('website') }}">
                                @if ($errors->has('website'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('website') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('owner') ? ' has-error' : '' }}">
                            <label for="owner" class="col-sm-2 control-label">Owner</label>
                            <div class="col-sm-8">
                                <input id="owner" type="text" class="form-control" name="owner" value="{{ !empty($edit_row->owner) ? $edit_row->owner : old('owner') }}">
                                @if ($errors->has('owner'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('owner') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('address') ? ' has-error' : '' }}">
                            <label for="address" class="col-sm-2 control-label">address</label>
                            <div class="col-sm-8">
                                <textarea name="address" id="address" cols="10" rows="5" class="form-control">{{ !empty($edit_row->address) ? $edit_row->address : old('address') }}</textarea>
                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-8 col-sm-offset-2 text-danger font-md" style="margin-bottom: 10px;">
                            Maximum logo size 1mb and ratio should be width*height =1*1
                        </div>
                        </div>

                        <div class="form-group{{ $errors->has('logo') ? ' has-error' : '' }}">
                            <label for="logo" class="col-sm-2 control-label">Logo</label>
                            <div class="col-sm-2">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <input id="logo" type="file" accept=".jpg, .png, .gif" name="logo" onchange="readURL(this);">
                                        <img id="logo_preview" src="" alt="" class="img-responsive mt15">
                                        @if(!empty($edit_row->logo))                                
                                        <span class="text-danger"> * Update will delete the old Logo automatically</span>
                                        @endif
                                        <script>
                                            function readURL(input)
                                            {
                                                if (input.files && input.files[0])
                                                {
                                                    var reader = new FileReader();
                                                    reader.onload = function (e)
                                                    {
                                                        $('#logo_preview')
                                                        .attr('src', e.target.result)
                                                    };
                                                    reader.readAsDataURL(input.files[0]);
                                                }
                                            }
                                        </script>
                                    </div>
                                </div>
                                @if ($errors->has('logo'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('logo') }}</strong>
                                    </span>
                                @endif
                            </div>

                            @if(!empty($edit_row->logo))
                            <label for="old_logo" class="col-sm-2 control-label">Old logo</label>
                            <div class="col-sm-2">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <img id="old_logo_preview" src="{{ asset('img/'.$edit_row->logo) }}" alt="" class="img-responsive img-thumbnail mt15">
                                        <input type="hidden" name="old_logo" value="{{ $edit_row->logo }}">
                                        <input type="checkbox" name="delete_old_logo"> Delete Old Logo <br>
                                    </div>
                                </div>
                            </div>
                            @endif
                        </div>

                        <div class="form-group{{ $errors->has('details') ? ' has-error' : '' }}">
                            <label for="details" class="col-sm-2 control-label">Details</label>
                            <div class="col-sm-8">
                                <textarea name="details" id="details" class="form-control">{{ !empty($edit_row->details) ? $edit_row->details : old('details') }}</textarea>
                                @if ($errors->has('details'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('details') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-success">
                                    {{ !empty($edit_row->name) ?  'Update' : 'Save' }}
                                </button>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('ckeditor/ckeditor.js') }}"></script>
<script>
    CKEDITOR.replace('address');
    CKEDITOR.replace('details');
</script>
@endsection
