@php $webInfos = webInfos() @endphp
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <link href="{{ !empty($webInfos->logo) ? asset('img/'.$webInfos->logo) : asset('img/sample_logo.jpg') }}" rel="icon" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title',!empty($webInfos->name) ? $webInfos->name : config('app.name'))</title>

    <!-- fonts -->
    <!-- <link href="https://fonts.googleapis.com/css?family=Bellefair" rel="stylesheet"> --><!-- font-family: 'Bellefair', serif; -->
    
    <!-- Bootstrap Core CSS -->
    <link href="{{ asset('font-awesome-4.7.0/css/font-awesome.min.css') }}" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="{{ asset('web/css/bootstrap-3.3.7.min.css') }}" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{ asset('css/sidebar.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">

    <!-- jQuery -->
    <script src="{{ asset('web/js/jquery-3.2.1.min.js') }}"></script>
    <script src="{{ asset('web/js/bootstrap-3.3.7.min.js') }}"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <div id="app">
        @include('dboard.navbar')

        <div id="wrapper">

            <!-- Sidebar -->
            @include('dboard.sidebar')
            <!-- /#sidebar-wrapper -->

            <!-- Page Content -->
            <div id="page-content-wrapper">
                <div class="container-fluid dark-font">
                    <div class="row">    
                        @yield('content')
                    </div>
                </div>
            </div>
            <!-- /#page-content-wrapper -->

        </div>
        <!-- /#wrapper -->

    </div>

    <!-- Bootstrap Core JavaScript -->
    <!-- <script src="{{ asset('web/js/bootstrap-3.3.7.min.js') }}"></script> -->

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    /*$('.nav a').on('click', function(){
        //$('.btn-navbar').click(); //bootstrap 2.x
        $('.navbar-toggle').click() //bootstrap 3.x by Richard
    });*/
    </script>

</body>
</html>
