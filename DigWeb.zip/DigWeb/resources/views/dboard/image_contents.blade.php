@extends('dboard.index')

@section('content')
<div class="panel panel-default">
	<div class="panel-heading">
		<strong>All Images</strong>
		<span class="pull-right db-add-btn">
			<a href="{{ url('add-image') }}" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add</a>
		</span>
	</div>
	<div class="panel-body">
		here goes body
	</div>
</div>
@endsection