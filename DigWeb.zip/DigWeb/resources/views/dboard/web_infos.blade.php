@extends('dboard.index')

@section('content')
<div class="panel panel-primary">
	<div class="panel-heading">
		<strong>Web Information</strong>
		<span class="pull-right db-add-btn">
			<a href="{{ !empty($web_infos) ? url('edit-web-infos') : url('add-web-infos') }}" class="btn btn-sm btn-default"><i class="fa fa-{{ !empty($web_infos) ? 'edit' : 'plus' }}"></i> {{ !empty($web_infos) ? 'Edit' : 'Add' }}</a>
		</span>
	</div>
	<div class="panel-body">
        <div class="row">
            <div class="col-sm-6 col-app-info">
                <div>App Name: <strong>{{ !empty($web_infos->name) ? $web_infos->name : config('app.name') }}</strong></div>
                <div>Subtitle: <strong>{{ !empty($web_infos->subtitle) ? $web_infos->subtitle : config('app.subtitle') }}</strong></div>
                <div>Email: <strong>{{ !empty($web_infos->email) ? $web_infos->email : config('app.email') }}</strong></div>
                <div>Contact No: <strong>{{ !empty($web_infos->contact_no) ? $web_infos->contact_no : config('app.contact_no') }}</strong></div>
                <div>Website: <strong>{{ !empty($web_infos->website) ? $web_infos->website : config('app.website') }}</strong></div>
                <div>Address: <strong>@php echo !empty($web_infos->address) ? $web_infos->address : config('app.address') @endphp</strong></div>
                <div>Owner: <strong>{{ !empty($web_infos->owner) ? $web_infos->owner : config('app.owner') }}</strong></div>
            </div>
            <div class="col-sm-6">
            @if(!empty($web_infos->logo))
                <img src="{{ asset('img/'.$web_infos->logo) }}" alt="{{ config('app.name') }}" class="img-responsive img-thumbnail app-logo">
            @else
                <img src="{{ asset('img/sample_logo.jpg') }}" alt="{{ config('app.name') }}" class="img-responsive img-thumbnail app-logo">
            @endif
            </div>
        </div>
        <div class="row col-app-info">
            <div class="col-sm-12"><strong>Details:</strong></div>
            <div class="col-sm-12">
                <strong>@php echo !empty($web_infos->details) ? $web_infos->details : config('app.details') @endphp</strong>
            </div>
        </div>
    </div>
</div>
@endsection