@extends('dboard.index')

@section('content')
@php $page_info = "" @endphp
@if (Session::has('page_info'))
@php $page_info = Session::get('page_info') @endphp
@endif
<div class="panel panel-default">
	<div class="panel-heading">
		<strong>All Page Contents</strong>
	</div>
	<div class="panel-body">
		
        <ul class="nav nav-tabs">
		@if(!empty($pages))
		@foreach($pages as $key => $menu)

		@php !empty($page_info->slug) ? $key = $key+1 : '' @endphp

		@if($menu->parent_id == 0)

        @if(count($menu->children) > 0 )
        <li class="dropdown {{ !empty($page_info->slug) && count($page_info->sections) > 0 && $page_info->parent_id == $menu->id ? 'active' : '' }}">
          	<a class="dropdown-toggle" data-toggle="dropdown" href="">{{ $menu->name }}</a>
          	<ul class="dropdown-menu">

          	@foreach($menu->children as $submenu)

          		@if($submenu->status == 1)
            	<li class="{{ !empty($page_info) && $page_info->slug == $submenu->slug ? 'active' : '' }}"><a href="#{{ $submenu->slug }}" data-toggle="tab"><i class="fa {{ !empty($submenu->fa_icon) ? $submenu->fa_icon : '' }}"></i> {{ $submenu->name }}</a></li>
          		@endif

          	@endforeach

          	</ul>
        </li> 
        @else
        <li class="{{ !empty($page_info) && $page_info->slug == $menu->slug || $key == 0 ? 'active' : '' }}"><a href="#{{ $menu->slug }}" data-toggle="tab"><i class="fa {{ !empty($menu->fa_icon) ? $menu->fa_icon : '' }}"></i> {{ $menu->name }}</a></li>
        @endif

        @endif

		@endforeach
		@endif
		</ul>
		
		<div class="tab-content">
		@if(!empty($pages))
		@foreach($pages as $key => $page)

		@php !empty($page_info->slug) ? $key = $key+1 : '' @endphp

			<div id="{{ $page->slug }}" class="tab-pane fade{{ !empty($page_info->slug) && $page_info->slug == $page->slug || $key == 0 ? ' in active' : '' }}">
		    	<h3>{{ $page->name }}
					<span class="pull-right db-add-btn">
						<a href="{{ url('add-section',$page->id) }}" class="btn btn-sm btn-success bold"><i class="fa fa-plus"></i> Add Section</a>
					</span>
					<span class="pull-right db-add-btn" style="margin-right: 5px;">
						<a href="#sectionHelpModal" data-toggle="modal" class="btn btn-sm btn-info bold"><i class="fa fa-info-circle"></i> Help</a>
					</span>
		    	</h3>

		    	@if(!empty($page->sections) && count($page->sections) > 0 )
		    	@foreach ($page->sections as $key => $section)
		    	
		    	@if($section->type == 'text')
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:{{ $section->title  }} No: {{ $section->order_no }}, Total Column: {{ $section->total_column }}, Type: {{ $section->type }}</strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="{{ url('edit-section',$section->id) }}" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="{{ url('delete-section',$section->id) }}" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="{{ url('add-text',$section->id) }}" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Text</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
			    		<div class="row">
			    			@foreach($section->texts as $key => $text)
			    			@php $col = 12/$section->total_column @endphp

			    			<div class="col-sm-{{ $col }}">
			    				<h3>Title: {{ $text->title ? $text->title : '' }}
				    				<span class="pull-right db-add-btn">
										<a href="{{ url('delete-text',$text->id) }}" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
									</span> 
				    				<span class="pull-right db-add-btn">
										<a href="{{ url('edit-text',$text->id) }}" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
									</span> 
				    			</h3>

				    			<h4>Subtitle: {{ $text->subtitle ? $text->subtitle : '' }}</h4>
				    			<small>Author: {{ $text->user->name }}, Date: {{ date('d-m-Y h:i:s'), strtotime($text->created_at) }}</small>

				    			@php echo $text->details @endphp
				    			
			    			</div>

			    			@endforeach
			    		</div>
		    		</div>
		    	</div>
		    	@elseif($section->type == 'image')
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:{{ $section->title  }} No: {{ $section->order_no }}, Total Column: {{ $section->total_column }}, Type: {{ $section->type }}</strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="{{ url('edit-section',$section->id) }}" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="{{ url('delete-section',$section->id) }}" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="{{ url('add-image',$section->id) }}" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Image</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
				    	<div class="row">
				    		@foreach($section->images as $key => $image)
				    		@php $col = 12/$section->total_column @endphp

			    			<div class="col-sm-{{ $col }}">
				    			<h3>Title: {{ $image->title ? $image->title : '' }}
				    				<span class="pull-right db-add-btn">
										<a href="{{ url('delete-image',$image->id) }}" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
									</span> 
				    				<span class="pull-right db-add-btn">
										<a href="{{ url('edit-image',$image->id) }}" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
									</span> 
				    			</h3>
				    			<h4>Caption: {{ $image->caption ? $image->caption : '' }}</h4>
				    			<div><strong> Linked to Page: {{ $image->url ? $image->url : 'None' }}</strong></div>
				    			<small>Author: {{ $image->user->name }}, Date: {{ date('d-m-Y h:i:s'), strtotime($image->created_at) }}</small>

				    			<div>
				    				<img src="{{ asset('cntimgs/'.$image->image) }}" alt="" class="img-responsive">
				    				@if(!empty($image->url))
				    				Link: <a href="#{{ $image->url }}" data-toggle="tab" class="btn btn-info link">{{ $image->url }}</a>
				    				@endif
				    			</div>
				    			
				    		</div>
				    		@endforeach
				    	</div>
		    		</div>
		    	</div>
		    	@elseif($section->type == 'article')
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:{{ $section->title  }} No: {{ $section->order_no }}, Total Column: {{ $section->total_column }}, Type: {{ $section->type }}</strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="{{ url('edit-section',$section->id) }}" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="{{ url('delete-section',$section->id) }}" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="{{ url('add-article',$section->id) }}" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Article</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
				    	<div class="row">
				    		@foreach($section->articles as $key => $article)
				    		@php $col = 12/$section->total_column @endphp

			    			<div class="col-sm-{{ $col }}">
				    			<h3>Title: {{ $article->title ? $article->title : '' }}
				    				<span class="pull-right db-add-btn">
										<a href="{{ url('delete-article',$article->id) }}" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
									</span> 
				    				<span class="pull-right db-add-btn">
										<a href="{{ url('edit-article',$article->id) }}" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
									</span> 
				    			</h3>
				    			<h4>Subtitle: {{ $article->subtitle ? $article->subtitle : '' }}</h4>
				    			<small>Author: {{ $article->user->name }}, Date: {{ date('d-m-Y h:i:s'), strtotime($article->created_at) }}</small>

				    			<div>
				    				<img src="{{ asset('cntimgs/'.$article->image) }}" alt="" class="img-responsive">
				    			</div>
				    			
				    			@php echo $article->details @endphp
				    		</div>
				    		@endforeach
				    	</div>
		    		</div>
		    	</div>
		    	@elseif($section->type == 'slide')
		    	<div class="panel panel-default">
		    		<div class="panel-heading">
		    			<div class="row">
		    				<div class="col-sm-12">
		    					<strong class="pull-left section-info">Section:{{ $section->title  }} No: {{ $section->order_no }}, Total Column: {{ $section->total_column }}, Type: {{ $section->type }}</strong>
				    			<span class="pull-left">
				    				<div class="dropdown">
									 	<button class="btn btn-xs btn-default dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-caret-down"></span></button>
									  	<ul class="dropdown-menu edit-dropdown">
									    	<li><a href="{{ url('edit-section',$section->id) }}" class=""><i class="fa fa-edit"></i> Edit</a></li>
									    	<li><a href="{{ url('delete-section',$section->id) }}" class="" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i> Delete</a></li>
									  	</ul>
									</div>
				    			</span>
				    			<span class="pull-right db-add-btn">
									<a href="{{ url('add-slide',$section->id) }}" class="btn btn-sm btn-primary bold"><i class="fa fa-plus"></i> Add Slide Image</a>
								</span>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="panel-body">
				    	<div class="row">
				    	@if(!empty($section->slides) && count($section->slides) > 0)
				    		
				    		@php $col = 12/$section->total_column @endphp

			    			<div class="col-sm-{{ $col }}">
			    			
				    			<!-- start carousel -->
								<div class="carousel-container">
								    <div id="myCarousel{{ $section->id }}" class="carousel slide carousel-fade">  
							        	<div class="carousel-inner">
							        	@foreach($section->slides as $key => $slide)
							        		<div class="item {{ $key == 0 ? ' active' : '' }}">
							        		<h3>Title: {{ $slide->title ? $slide->title : '' }}
							    				<span class="pull-right db-add-btn">
													<a href="{{ url('delete-slide',$slide->id) }}" class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to delete it?')"><i class="fa fa-trash"></i></a>
												</span> 
							    				<span class="pull-right db-add-btn">
													<a href="{{ url('edit-slide',$slide->id) }}" class="btn btn-xs btn-info"><i class="fa fa-edit"></i></a>
												</span> 
							    			</h3>
							        			
							        		</span>
							              		<img src="{{ asset('cntimgs/'.$slide->image) }}" alt="{{ $slide->caption }}">
							              		<div class="container">
							                		<div class="carousel-caption">
							                  			<p class="caption animated bounceInUp">{{ $slide->caption }}</p>
							                		</div>
							              		</div>
							            	</div>
							            @endforeach
							        	
									        <!-- Controls -->
									        <a class="left carousel-control" href="#myCarousel{{ $section->id }}" data-slide="prev"><span class="fa fa-chevron-left"></span></a>
									        <a class="right carousel-control" href="#myCarousel{{ $section->id }}" data-slide="next"><span class="fa fa-chevron-right"></span></a>
							      		</div>
							    	</div>
							    </div>

							  	<!-- end carousel -->
				    			<script>
									// carousel interval
									$("#myCarousel{{ $section->id }}").carousel({interval: 2000});
								  	// Register keyboard events
								  	$(document).keydown(function(e) {
								    	if (e.keyCode === 37) {
								       		// Previous
								       		$(".carousel-control.left").click();
								       		return false;
								    	}
								    	if (e.keyCode === 39) {
								       		// Next
								       		$(".carousel-control.right").click();
								       		return false;
								    	}
									});
								</script>
							
				    		</div>
				    	@endif
				    	</div>
		    		</div>
		    	</div>
		    	@endif

		    	@endforeach
		    	@endif
		    	
		  	</div>
		@endforeach
		@endif
		</div>
		
	</div>
</div>
<!-- Modal -->
<div id="sectionHelpModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center">FAQ about Section</h4>
      </div>
      <div class="modal-body font-md">
        <ul class="list-group">
		  <li class="list-group-item">1. Every page is generated with sections. A page has one or more sections. This is the primary part for a page to add something according to type.</li>
		  <li class="list-group-item text-primary">2. There are 4 types of section. 1 - Text type which contains only textual contents, 2 - Image type whiche contains only image type contents, 3 - Article type which can contain both text and image content and 4 - Slide type which contains image slider.</li>
		  <li class="list-group-item text-danger">3. Every section must be defined which type it is and what is the order no of the section for it's associative page.</li>
		  <li class="list-group-item text-danger">4. Total Column number is essential to set how many columsn will take the section. For Slide type section, you should never set column number more than 1. If you want to show 2 mages per row or as a set in the section i image type section just set column no as 2. If you skip the field, system will set total column no 1 by default.</li>
		</ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
@endsection