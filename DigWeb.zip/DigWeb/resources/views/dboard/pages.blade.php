@extends('dboard.index')

@section('content')
<div class="panel panel-default">
	<div class="panel-heading">
		<strong>All Web Pages</strong>
		<span class="pull-right db-add-btn">
			<a href="{{ url('add-page') }}" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add</a>
		</span>
	</div>
	<div class="panel-body">
		<div class="alert alert-primary bold">
			<strong class="text-primary"><i class="fa fa-sort-amount-asc"></i></strong>   - this icon defines the page is a child page
		</div>
		<div class="alert alert-primary bold">
			<strong class="text-primary">navbar</strong>   - type define the menu not a page, it is a navigation bar only
		</div>
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover table-condensed">
				<thead>
					<tr>
						<th nowrap="">Sl.</th>
						<th nowrap="">Webpage / Navbar</th>
						<th nowrap="">Parent</th>
						<th nowrap="">Slug / Url</th>
						<th nowrap="">type</th>
						<th nowrap="">Order No</th>
						<th nowrap="">Fa Icon</th>
						<th nowrap="">Meta Title</th>
						<th nowrap="">Meta Details</th>
						<th nowrap="">Language</th>
						<th nowrap="">Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
				@if(!empty($pages))
					@foreach($pages as $key => $web)
					<tr>
						<td>{{ $key+1 }}</td>
						<td class="text-primary text-center bold" style="font-size: 120%;vertical-align: inherit;"><i class="fa fa{{ $web->parent_id ? '-sort-amount-asc' : '' }}"></i> {{ $web->name }}</td>
						<td>{{ $web->parent_id ? $web->parent->name : 'No Parent' }}</td>
						<td>{{ $web->slug }}</td>
						<td class="text-{{ $web->type == 'navbar' ? 'primary bold' : 'success' }}">{{ $web->type }}</td>
						<td class="text-center"><i class="fa fa-{{ $web->parent_id ? 'sort-amount-asc' : '' }}"></i> {{ $web->order_no }}</td>
						<td>{{ $web->fa_icon }}</td>
						<td>{{ $web->meta_title }}</td>
						<td>@php echo $web->meta_details @endphp</td>
						<td>{{ !empty($web->lang->name) ? $web->lang->name : 'Not Set' }}</td>
						<td nowrap="" class="text-center" style="color: {{ $web->status == 1 ? 'green' : 'red' }}">{{ $web->status == 1 ? 'Active' : 'Inactive' }}</td>
                        <td>
                            <a href="{{ url('edit-page',[$web->id]) }}" class="btn btn-xs btn-success btn-block"><i class="fa fa-edit"></i> Edit</a>
                            <a href="{{ url('delete-page',[$web->id]) }}" class="btn btn-xs btn-danger btn-block"><i class="fa fa-trash"></i> Delete</a>
                        </td>
					</tr>
					@endforeach
				@endif
				</tbody>
			</table>
		</div>
	</div>
</div>
@endsection