@extends('dboard.index')

@section('content')
<div class="panel panel-default">
	<div class="panel-heading">
		<strong>All Text Contents</strong>
		<span class="pull-right db-add-btn">
			<a href="{{ url('add-text') }}" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add</a>
		</span>
	</div>
	<div class="panel-body">
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<tr>
						<th>Sl</th>
						<th>Page</th>
						<th>Title</th>
						<th>Subtitle</th>
						<th>Type</th>
						<th>Order no</th>
						<th>Image</th>
						<th>Details</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
				@if(!empty($texts))
					@foreach($texts as $key => $text)
					<tr>
						<td>{{ $key+1 }}</td>
						<td>{{ $text->web->name }}</td>
						<td>{{ $text->title }}</td>
						<td>{{ $text->subtitle }}</td>
						<td>{{ $text->type }}</td>
						<td>{{ $text->order_no }}</td>
						<td>{{ $text->image }}</td>
						<td>@php echo $text->details @endphp</td>
                        <td style="color: {{ $text->status == 1 ? 'green' : 'red' }}">{{ $text->status == 1 ? 'Active' : 'Inactive' }}</td>
                        <td>
                            <a href="{{ url('edit-text',$text->id) }}" class="btn btn-xs btn-success btn-block"><i class="fa fa-edit"></i> Edit</a>
                            <a href="{{ url('delete-text',$text->id) }}" class="btn btn-xs btn-danger btn-block"><i class="fa fa-trash"></i> Delete</a>
                        </td>
					</tr>
					@endforeach
				@endif
				</tbody>
			</table>
		</div>
	</div>
</div>
@endsection