@extends('dboard.index')

@section('content')
<div class="panel panel-default">
	<div class="panel-heading">
		<strong>All Languages</strong>
		<span class="pull-right db-add-btn">
			<a href="{{ url('add-lang') }}" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add</a>
		</span>
	</div>
	<div class="panel-body">
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<tr>
						<th>Sl.</th>
						<th>Name</th>
						<th>2 Fonts Code </th>
						<th>3 Fonts Code </th>
						<th>Type</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
				@if(!empty($langs))
					@foreach($langs as $key => $lang)
					<tr>
						<td>{{ $key+1 }}</td>
						<td>{{ $lang->name }}</td>
						<td>{{ $lang->code_2f }}</td>
						<td>{{ $lang->code_3f }}</td>
						<td>{{ $lang->type }}</td>
						<td nowrap="" class="text-center" style="color: {{ $lang->status == 1 ? 'green' : 'red' }}">{{ $lang->status == 1 ? 'Active' : 'Inactive' }}</td>
                        <td>
                            <a href="{{ url('edit-lang',[$lang->id]) }}" class="btn btn-xs btn-success btn-block"><i class="fa fa-edit"></i> Edit</a>
                            <!-- <a href="{{ url('delete-lang',[$lang->id]) }}" class="btn btn-xs btn-danger btn-block"><i class="fa fa-trash"></i> Delete</a> -->
                        </td>
					</tr>
					@endforeach
				@endif
				</tbody>
			</table>
		</div>
	</div>
</div>
@endsection