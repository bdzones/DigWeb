@extends('dboard.index')

@section('content')
<div class="panel panel-success">
	<div class="panel-heading">
		<strong>Add Language</strong>
        <span class="pull-right db-add-btn">
            <a href="{{ url('all-langs') }}" class="btn btn-sm btn-info bold"><i class="fa fa-plus"></i> All Languages</a>
        </span>
	</div>
	<div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="{{ !empty($edit_row) ? url('update-lang',[$edit_row->id]) : url('store-lang') }}" enctype="multipart/form-data">
            {{ csrf_field() }}
            @if(!empty($edit_row))
            {{ method_field('PATCH') }}
            @endif

            @if (Session::has('message'))
            <div class="row">
                <div class="col-sm-6 col-sm-offset-2 alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Warning!</strong> {{ Session::get('message') }}
                </div>
            </div>
            @endif

            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                <label for="name" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-6">
                    <input id="name" type="text" class="form-control" name="name" value="{{ !empty($edit_row->name) ? $edit_row->name : old('name') }}" required="">
                    @if ($errors->has('name'))
                        <span class="help-block">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group{{ $errors->has('code_2f') ? ' has-error' : '' }}">
                <label for="code_2f" class="col-sm-2 control-label">2 Fonts Code</label>
                <div class="col-sm-6">
                    <input id="code_2f" type="text" class="form-control" name="code_2f" value="{{ !empty($edit_row->code_2f) ? $edit_row->code_2f : old('code_2f') }}" required="">
                    @if ($errors->has('code_2f'))
                        <span class="help-block">
                            <strong>{{ $errors->first('code_2f') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group{{ $errors->has('code_3f') ? ' has-error' : '' }}">
                <label for="code_3f" class="col-sm-2 control-label">3 Fonts Code</label>
                <div class="col-sm-6">
                    <input id="code_3f" type="text" class="form-control" name="code_3f" value="{{ !empty($edit_row->code_3f) ? $edit_row->code_3f : old('code_3f') }}" required="">
                    @if ($errors->has('code_3f'))
                        <span class="help-block">
                            <strong>{{ $errors->first('code_3f') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group{{ $errors->has('type') ? ' has-error' : '' }}">
                <label for="type" class="col-sm-2 control-label">Type</label>
                <div class="col-sm-6">
                    <input id="type" type="text" class="form-control" name="type" value="{{ !empty($edit_row->type) ? $edit_row->type : old('type') }}" required="">
                    @if ($errors->has('type'))
                        <span class="help-block">
                            <strong>{{ $errors->first('type') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group{{ $errors->has('status') ? ' has-error' : '' }}">
                <label for="status" class="col-sm-2 control-label">Status</label>
                <div class="col-sm-6">
                    <label class="radio-inline"><input type="radio" name="status" value="1" checked="" {{ !empty($edit_row) && $edit_row->status == 1 ? 'checked' : '' }}>Active</label>
                    <label class="radio-inline"><input type="radio" name="status" value="2" {{ !empty($edit_row) && $edit_row->status == 2 ? 'checked' : '' }}>Inactive</label>
                    @if ($errors->has('status'))
                        <span class="help-block">
                            <strong>{{ $errors->first('status') }}</strong>
                        </span>
                    @endif
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-6 col-sm-offset-2">
                    <div class="col-sm-6">
                        <div class="row">
                            <button type="submit" class="btn btn-primary fullwidth">
                            {{ !empty($edit_row->id) ?  'Update' : 'Save' }}
                        </button>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <input type="reset" class="btn btn-warning fullwidth">
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
@endsection