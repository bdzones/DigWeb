@extends('dboard.index')

@section('content')
<div class="panel panel-default">
    <div class="panel-heading text-center">
        <strong>Add Article to Section: <span class="text-primary">{{ $section->order_no }}</span> of Page: <span class="text-primary">{{ $page->name }}</span></strong>
    </div>
    <div class="panel-body">
        <form class="form-horizontal" role="form" method="POST" action="{{ !empty($edit_row) ? url('update-article',[$edit_row->id]) : url('store-article') }}" enctype="multipart/form-data">
            {{ csrf_field() }}
            @if(!empty($edit_row))
            {{ method_field('PATCH') }}
            @endif

            @if (Session::has('message'))
            <div class="row">
                <div class="col-sm-6 col-sm-offset-2 alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Warning!</strong> {{ Session::get('message') }}
                </div>
            </div>
            @endif

            @if(!empty($langs))
            <div class="form-group{{ $errors->has('lang_id') ? ' has-error' : '' }}">
                <label for="lang_id" class="col-sm-2 control-label">Language</label>
                <div class="col-sm-6">
                    <select name="lang_id" id="lang_id" class="form-control">
                        <option value="">select</option>
                        @foreach ($langs as $key => $lang)
                        <option value="{{ $lang->id }}" {{ !empty($edit_row) && $edit_row->lang_id == $lang->id || old('lang_id') == $lang->id ? 'selected' : '' }}>{{ $lang->name }}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('lang_id'))
                        <span class="help-block">
                            <strong>{{ $errors->first('lang_id') }}</strong>
                        </span>
                    @endif
                </div>
            </div>
            @endif

            @if(!empty($page))
            <div class="form-group{{ $errors->has('cntwb_id') ? ' has-error' : '' }}">
                <label for="cntwb_id" class="col-sm-2 control-label">Page</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" id="cntwb_id" value="{{ $page->name }}" disabled="">
                    <input type="hidden" name="cntwb_id" value="{{ $page->id }}">
                    <input type="hidden" name="cntsec_id" value="{{ $section->id }}">
                    @if ($errors->has('cntwb_id'))
                        <span class="help-block">
                            <strong>{{ $errors->first('cntwb_id') }}</strong>
                        </span>
                    @endif
                </div>
            </div>
            @endif

            <div class="form-group{{ $errors->has('title') ? ' has-error' : '' }}">
                <label for="title" class="col-sm-2 control-label">Title</label>
                <div class="col-sm-6">
                    <input id="title" type="text" class="form-control" name="title" value="{{ !empty($edit_row->title) ? $edit_row->title : old('title') }}" required="" autofocus="" placeholder="add title here..">
                    @if ($errors->has('title'))
                        <span class="help-block">
                            <strong>{{ $errors->first('title') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="col-sm-2 text-danger">Required</div>
            </div>

            <div class="form-group{{ $errors->has('subtitle') ? ' has-error' : '' }}">
                <label for="subtitle" class="col-sm-2 control-label">Subtitle</label>
                <div class="col-sm-6">
                    <input id="subtitle" type="text" class="form-control" name="subtitle" value="{{ !empty($edit_row->subtitle) ? $edit_row->subtitle : old('subtitle') }}" placeholder="add subtitle here...">
                    @if ($errors->has('subtitle'))
                        <span class="help-block">
                            <strong>{{ $errors->first('subtitle') }}</strong>
                        </span>
                    @endif
                </div>
            </div>

            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 text-danger font-md" style="margin-bottom: 10px;">
                Maximum image size 1mb
            </div>
            </div>

            <div class="form-group{{ $errors->has('image') ? ' has-error' : '' }}">
                <label for="image" class="col-sm-2 control-label">Image</label>
                <div class="col-sm-2">
                    <div class="row">
                        <div class="col-sm-12">
                            <input id="image" type="file" accept=".jpg, .png, .gif" name="image" onchange="readURL(this);">
                            <img id="image_preview" src="" alt="" class="img-responsive mt15">
                            @if(!empty($edit_row->image))                                
                            <span class="text-danger"> * Update will delete the old image automatically</span>
                            @endif
                            <script>
                                function readURL(input)
                                {
                                    if (input.files && input.files[0])
                                    {
                                        var reader = new FileReader();
                                        reader.onload = function (e)
                                        {
                                            $('#image_preview')
                                            .attr('src', e.target.result)
                                        };
                                        reader.readAsDataURL(input.files[0]);
                                    }
                                }
                            </script>
                        </div>
                    </div>
                    @if ($errors->has('image'))
                        <span class="help-block">
                            <strong>{{ $errors->first('image') }}</strong>
                        </span>
                    @endif
                </div>

                @if(!empty($edit_row->image))
                <label for="old_image" class="col-sm-2 control-label">Old Image</label>
                <div class="col-sm-2">
                    <div class="row">
                        <div class="col-sm-12">
                            <img id="old_image_preview" src="{{ asset('TxtImg/'.$edit_row->image) }}" alt="" class="img-responsive img-thumbnail mt15">
                            <input type="hidden" name="old_image" value="{{ $edit_row->image }}">
                            <input type="checkbox" name="delete_old_image"> Delete Old image <br>
                        </div>
                    </div>
                </div>
                @endif
            </div>

            <div class="form-group{{ $errors->has('order_no') ? ' has-error' : '' }}">
                <label for="order_no" class="col-sm-2 control-label">Order No</label>
                <div class="col-sm-6">
                    <input id="order_no" type="number" class="form-control" name="order_no" value="{{ !empty($edit_row->order_no) ? $edit_row->order_no : old('order_no') }}">
                    @if ($errors->has('order_no'))
                        <span class="help-block">
                            <strong>{{ $errors->first('order_no') }}</strong>
                        </span>
                    @endif
                </div>
            </div>

            <div class="form-group{{ $errors->has('details') ? ' has-error' : '' }}">
                <label for="details" class="col-sm-2 control-label">Details</label>
                <div class="col-sm-6">
                    <textarea name="details" id="details" cols="10" rows="5" class="form-control" placeholder="add details here...">{{ !empty($edit_row->details) ? $edit_row->details : old('details') }}</textarea>
                    @if ($errors->has('details'))
                        <span class="help-block">
                            <strong>{{ $errors->first('details') }}</strong>
                        </span>
                    @endif
                </div>
            </div>

            <div class="form-group{{ $errors->has('status') ? ' has-error' : '' }}">
                <label for="status" class="col-sm-2 control-label">Status</label>
                <div class="col-sm-6">
                    <label class="radio-inline"><input type="radio" name="status" value="1" checked="" {{ !empty($edit_row) && $edit_row->status == 1 ? 'checked' : '' }}>Active</label>
                    <label class="radio-inline"><input type="radio" name="status" value="2" {{ !empty($edit_row) && $edit_row->status == 2 ? 'checked' : '' }}>Inactive</label>
                    @if ($errors->has('status'))
                        <span class="help-block">
                            <strong>{{ $errors->first('status') }}</strong>
                        </span>
                    @endif
                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-6 col-sm-offset-2">
                    <div class="col-sm-6">
                        <div class="row">
                            <button type="submit" class="btn btn-primary btn-block">
                            {{ !empty($edit_row->id) ?  'Update' : 'Save' }}
                        </button>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <input type="reset" class="btn btn-warning btn-block">
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>
<script src="{{ asset('ckeditor/ckeditor.js') }}"></script>
<script>
    CKEDITOR.replace('details');
</script>
@endsection