            <div id="sidebar-wrapper">
                <ul class="sidebar-nav">
                    @if(Auth::user() && Auth::user()->type == 'system')
                    <li class="system-nav">
                        <a href="#system-bar" data-toggle="collapse">System</a>
                        <ul id="system-bar" class="collapse system-bar">
                            <li><a href="{{ url('all-langs') }}">Languages</a></li>
                            <li><a href="{{ url('web-infos') }}">Web Infos</a></li>
                        </ul>
                    </li>
                    @endif
                    <li><a href="{{ url('all-pages') }}">Pages</a></li>
                    <li><a href="{{ url('all-page-contents') }}">Page Contents</a></li>
                    <!-- <li><a href="{{ url('all-texts') }}">Texts</a></li>
                    <li><a href="{{ url('all-images') }}">Images</a></li>
                    <li><a href="{{ url('all-orders') }}">Orders</a></li>
                    <li><a href="{{ url('all-sales') }}">Sale Reports</a></li>
                    <li><a href="{{ url('/all-slides') }}">Slide Images</a></li>
                    <li><a href="{{ url('/all-contents') }}">Text Contents</a></li> -->
                </ul>
            </div>