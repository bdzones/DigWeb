
<footer class="container-fluid text-center">
  <div class="row mtb30">
  	<!-- <div class="container">
  		<div class="row"> -->
  			<div class="col-sm-4">
		  		<div class="fb-page" data-href="https://www.facebook.com/bdzones/" data-tabs="timeline" data-height="200" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/bdzones/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/bdzones/">BDzones</a></blockquote></div>
		  	</div>
		  	<div class="col-sm-4 text-center">
		  		<div class="col-sm-12">
	  				<h4 class="text-center bold bb-gray pb-10 font-light">Social Shares</h4>
	  			</div>
		  		<span><a href="#"><img class="img-social-icon" src="{{ asset('img/google_circle.png') }}" alt="Google Plus"></a></span>
		  		<span><a href="#"><img class="img-social-icon" src="{{ asset('img/facebook_circle.png') }}" alt="Facebook"></a></span>
		  		<span><a href="#"><img class="img-social-icon" src="{{ asset('img/linkedin_circle.png') }}" alt="LinkedIn"></a></span>
		  		<span><a href="#"><img class="img-social-icon" src="{{ asset('img/instagram_circle.png') }}" alt="Instagram"></a></span>
		  		<span><a href="#"><img class="img-social-icon" src="{{ asset('img/youtube_circle.png') }}" alt="Youtube"></a></span>
		  	</div>
		  	<div class="col-sm-4 text-left">
		  		<address class="row">
		  			<div class="col-sm-12">
		  				<h4 class="text-center bold bb-gray pb-10">Our Address</h4>
		  			</div>
		  			<div class="col-sm-12">
		  				<strong>{{ config('app.name') }}</strong>
		  			</div>
		  			<div class="col-sm-12">
		  				<i class="fa fa-map-marker"></i> 
		  			</div>
		  			<div class="col-sm-12">
		  				<i class="fa fa-envelope"></i> 
		  			</div>
		  			<div class="col-sm-12">
		  				<i class="fa fa-phone"></i> 
		  			</div>
		  		</address>
		  	</div>
  		<!-- </div>
  		  	</div> -->
  </div>
  <div class="row mtb30">
  	<div class="container">
			<div class="col-sm-12 text-center">
		  	<div class="">
		  		<a href="#myPage" title="To Top">
		    		<span class="fa fa-angle-up"></span>
		  		</a>
		  		<p>{{ date('Y') }} - All Rights Reserved by <a class="footer-home-link" href="{{ url('/') }}"><strong>{{ config('app.name') }}</strong></a> <i style="color: black;">developed by <a href="http://www.bdzones.com/" target="_blank"><img src="{{ asset('img/BDZONES.png') }}" alt="BDZONES" class="footer-bdzones"></a></i></p>
		  	</div>
	  	</div>
  </div>
</footer>