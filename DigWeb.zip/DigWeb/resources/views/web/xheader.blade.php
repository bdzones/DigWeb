<div class="container-fluid theme-color">
  <div class="row">
    <header class="container header-box" style="margin-bottom: -2px !important;">
      <div class="header-banner row clearfix">
        <div class="header-logo">
          <a href="home">
            <img src="{{ asset('img/sample_logo.jpg') }}" class="img-responsive header-logo-img"  alt="LOGO">
          </a>
        </div>
        <div class="header-title">
          <h1>{{ config('app.name') }}</h1>
          <div class="header-subtitle">
            <span>{{ config('app.subtitle') }}</span>
          </div>
        </div>
        <div class="header-right-box">
          <div class="row">
            <div class="col-sm-12"><i class="fa fa-envelope"></i> {{ config('app.email') }}</div>
          </div>
        </div>
        <div class="clearBoth"></div>
      </div>
    </header>
  </div>
</div>

<nav class="navbar navbar-inverse{{ Auth::user() && Auth::user()->weight >= 79.99 ? ' dbar-nav' : '' }}" data-spy="affix" data-offset-top="130">
    <div class="container-fluid">
        <div class="navbar-header">

            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <!-- Branding Image -->
            <a class="navbar-brand" href="{{ url('/') }}">
                {{ config('app.name') }}
            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav">
            @php $menus = menuArray() @endphp

            @if(!empty($menus))
            
            @foreach($menus as $menu)
            
            @if($menu->parent_id == 0)

            @if(count($menu->children) > 0 )
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="">{{ $menu->name }}</a>
              <ul class="dropdown-menu">

              @foreach($menu->children as $submenu)

              @if($submenu->status == 1)
                <li><a href="{{ url('page',$submenu->slug) }}"><i class="fa {{ !empty($submenu->fa_icon) ? $submenu->fa_icon : '' }}"></i> {{ $submenu->name }}</a></li>
              @endif

              @endforeach

              </ul>
            </li> 
            @else
            <li><a href="{{ url('page',$menu->slug) }}"><i class="fa {{ !empty($menu->fa_icon) ? $menu->fa_icon : '' }}"></i> {{ $menu->name }}</a></li>
            @endif

            @endif
            
            @endforeach
            
            @endif

            @if(Auth::user() && Auth::user()->weight >= 79.99)
            <li><a class="btn btn-xs btn-danger" href="{{ url('/dboard') }}">Dboard</a></li>
            @endif
          </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                <!-- Authentication Links -->
                @guest
                    <li><a href="{{ route('login') }}">Login</a></li>
                    <li><a href="{{ route('register') }}">Register</a></li>
                @else
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            {{ Auth::user()->name }} <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </li>
                        </ul>
                    </li>
                @endguest
            </ul>
        </div>
    </div>
</nav>