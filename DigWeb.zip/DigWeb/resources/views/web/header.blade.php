@php $webInfos = webInfos() @endphp
        <nav class="navbar navbar-default navbar-fixed-top{{ Auth::user() && Auth::user()->weight >= 79.99 ? ' dbar-nav' : '' }}">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="{{ url('/') }}"><img class="img-responsive logo" src="{{ !empty($webInfos->logo) ? asset('img/'.$webInfos->logo) : asset('img/sample_logo.jpg') }}" alt="{{ !empty($webInfos->name) ? $webInfos->name : config('app.name') }}"></a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <!-- <ul class="nav navbar-nav">
                        
                    </ul> -->

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        @php $menus = menuArray() @endphp

                        @if(!empty($menus))
                        
                        @foreach($menus as $menu)
                        
                        @if($menu->parent_id == 0)

                        @if(count($menu->children) > 0 )
                        <li class="dropdown">
                          <a class="dropdown-toggle" data-toggle="dropdown" href="">{{ $menu->name }}</a>
                          <ul class="dropdown-menu nav-dropdown">

                          @foreach($menu->children as $submenu)

                          @if($submenu->status == 1)
                            <li><a href="{{ url('page',$submenu->slug) }}"><i class="fa {{ !empty($submenu->fa_icon) ? $submenu->fa_icon : '' }}"></i> {{ $submenu->name }}</a></li>
                          @endif

                          @endforeach

                          </ul>
                        </li> 
                        @else
                        <li><a href="{{ url('page',$menu->slug) }}"><i class="fa {{ !empty($menu->fa_icon) ? $menu->fa_icon : '' }}"></i> {{ $menu->name }}</a></li>
                        @endif

                        @endif
                        
                        @endforeach
                        
                        @endif
                        <!-- Authentication Links -->
                        {{--@guest
                            <li><a href="{{ route('login') }}">Login</a></li>
                            <!-- <li><a href="{{ route('register') }}">Register</a></li> -->
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu nav-dropdown" role="menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endguest--}}
                    </ul>
                </div>
            </div>
        </nav>