@extends('web.index')
@section('title','Home')
@section('content')
	
<div class="container-fluid">
	<div class="row">
		<!-- start carousel -->
		<div class="carousel-container">
		    <div id="myCarousel" class="carousel slide carousel-fade">  
	        	<div class="carousel-inner">

	        	{{--@if(!empty($slides))
	        	@foreach($slides as $key => $slide)
	        		<div class="item {{ $key == 0 ? 'active' : '' }}">
	              		<img src="{{ asset('img_products/'.$slide->image) }}" alt="{{ $slide->caption }}">
	              		<div class="container">
	                		<div class="carousel-caption">
	                  			<p class="caption animated bounceInUp">{{ $slide->caption }}</p>
	                		</div>
	              		</div>
	            	</div>
	        	@endforeach
	        	@endif--}}

	        		<div class="item active">
	              		<img src="{{ asset('imgs/Jellyfish.jpg') }}" alt="">
	              		<div class="container">
	                		<div class="carousel-caption">
	                  			<p class="caption animated bounceInUp">caption</p>
	                		</div>
	              		</div>
	            	</div>

	            	<div class="item">
	              		<img src="{{ asset('imgs/Koala.jpg') }}" alt="">
	              		<div class="container">
	                		<div class="carousel-caption">
	                  			<p class="caption animated bounceInUp">caption</p>
	                		</div>
	              		</div>
	            	</div>

	            	<div class="item">
	              		<img src="{{ asset('imgs/Lighthouse.jpg') }}" alt="">
	              		<div class="container">
	                		<div class="carousel-caption">
	                  			<p class="caption animated bounceInUp">caption</p>
	                		</div>
	              		</div>
	            	</div>

			        <!-- Controls -->
			        <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="fa fa-chevron-left"></span></a>
			        <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="fa fa-chevron-right"></span></a>
	      		</div>
	    	</div>
	    </div>
	  	<!-- end carousel -->
	</div>
</div>

<div class="container-fluid theme-bg theme-font-color">
	<div class="row">
		<div class="container p-tb-60">
			<div class="">
				<div class="col-sm-12 text-center">
					<h1 class="sec-h1">Welcome to Oblique Sourcing</h1>
				</div>
				<div class="col-sm-12 text-justify">
					We are expert in sourcing Leathers, Readymade garments, Home textiles, Jute, Ceramic/porcelain products, Footwear, Furniture. We are a complete sourcing company from design to delivery. We also develop samples from the designs provided by the clients. We consider ourselves as dedicated, experienced, hardworking and sincere agent with the industry intelligence in respective sectors. We are good negotiator and always offer a win-win situation for our clients. We keep close liaison with the manufacturers and factories to ensure competitive advantages, so that you can source any type of articles from Bangladesh with confidence. We maintain necessary follow up with the factories during the production process to ensure IN-TIME DELIVERY and QUALITY ASSURANCE. Thank you again for your kind patience. We will be waiting eagerly to get any enquiry from you.
				</div>
			</div>
		</div>
	</div>
</div>

<div class="container-fluid">
	<div class="row">
		<div class="container p-tb-60">
			<div class="">
				<div class="col-sm-12 text-center">
					<h2 class="sec-h1">Our Product</h2>
					<div class="sec-sub-h mb15">Our Product are .....</div>
				</div>
				<div class="com-sm-12 text-justify">
					<div class="row">
						<div class="col-sm-6 text-center">
							<div class="pro-img-box">
								<div class="pro-img">
									<img src="{{ asset('imgs/Koala.jpg') }}" alt="" class="img-responsive">
								</div>
								<div class="mt15 font-md">
									<strong>category Name</strong>
								</div>
								<div class="mb10">
									here gopes some feature
								</div>
								<div class="mt15">
									<a href="" class="btn btn-primary btn-product">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6 text-center">
							<div class="pro-img-box">
								<div class="pro-img">
									<img src="{{ asset('imgs/Koala.jpg') }}" alt="" class="img-responsive">
								</div>
								<div class="mt15 font-md">
									<strong>category Name</strong>
								</div>
								<div class="mb10">
									here gopes some feature
								</div>
								<div class="mt15">
									<a href="" class="btn btn-primary btn-product">Read More</a>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6 text-center">
							<div class="pro-img-box">
								<div class="pro-img">
									<img src="{{ asset('imgs/Koala.jpg') }}" alt="" class="img-responsive">
								</div>
								<div class="mt15 font-md">
									<strong>category Name</strong>
								</div>
								<div class="mb10">
									here gopes some feature
								</div>
								<div class="mt15">
									<a href="" class="btn btn-primary btn-product">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6 text-center">
							<div class="pro-img-box">
								<div class="pro-img">
									<img src="{{ asset('imgs/Koala.jpg') }}" alt="" class="img-responsive">
								</div>
								<div class="mt15 font-md">
									<strong>category Name</strong>
								</div>
								<div class="mb10">
									here gopes some feature
								</div>
								<div class="mt15">
									<a href="" class="btn btn-primary btn-product">Read More</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="container-fluid sp-bg">
	<div class="">
		<div class="container text-center fa-2x">
			here goes some extensive quote
		</div>
	</div>
</div>

<script>
	// carousel interval
	$("#myCarousel").carousel({interval: 2000});
  	// Register keyboard events
  	$(document).keydown(function(e) {
    	if (e.keyCode === 37) {
       		// Previous
       		$(".carousel-control.left").click();
       		return false;
    	}
    	if (e.keyCode === 39) {
       		// Next
       		$(".carousel-control.right").click();
       		return false;
    	}
	});
</script>

@endsection