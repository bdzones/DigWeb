@extends('web.index')
@section('title',$page->name)
@section('content')

@if(!empty($page->sections) && count($page->sections) > 0)

@if($page->slug != 'home')
<div class="container-fluid">
	<div class="row">
		<div class="container mt30">
			<h1 class="page-title">{{ $page->name }}</h1>
			<hr>
		</div>
	</div>
</div>
@endif

@foreach($page->sections as $key => $section)
@if($section->type == 'text' && count($section->texts) > 0 )
<div class="container{{ !empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid' }} {{ $section->id == 4 ? 'sp-bg' : '' }}" style="background-color: {{ !empty($section->bg_color) ? $section->bg_color : 'transparent' }};color: {{ !empty($section->font_color) ? $section->font_color : 'inherit' }}; padding:{{ !empty($section->padding) ? $section->padding : '0' }};text-align: {{ !empty($section->text_align) ? $section->text_align : '' }};">
	<div class="">
		<section id="{{ $section->id }}" class="container{{ !empty($section->content_width) && $section->content_width == 1 ? '' : '-fluid' }}">

			@if(!empty($section->title))
			<div class="col-sm-12">
				<h2 class="section-heading">{{ $section->title }}</h2>
			</div>
			@endif

			@foreach($section->texts as $key => $text)
			@php $col = 12/$section->total_column @endphp
			<div class="col-sm-{{ $col }}">
				
				@if($section->id != 4)
				@if(!empty($text->title))
				<div class="row">
					<h1><b>{{ $text->title }}</b></h1>
				</div>
				@endif
				@endif

				@if(!empty($text->subtitle))
				<div><i>{{ $text->subtitle }}</i></div>
				@endif

				<div class="row">
					@php echo $text->details ? $text->details : '' @endphp
				</div>

			</div>
			@endforeach

		</section>
	</div>
</div>
@elseif($section->type == 'article' && count($section->articles) > 0 )
<div class="container{{ !empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid' }}" style="background-color: {{ !empty($section->bg_color) ? $section->bg_color : 'transparent' }}; color: {{ !empty($section->font_color) ? $section->font_color : 'inherit' }}; padding:{{ !empty($section->padding) ? $section->padding : '0' }};text-align: {{ !empty($section->text_align) ? $section->text_align : '' }};">
	<div class="">
		<section id="{{ $section->id }}" class="container{{ !empty($section->content_width) && $section->content_width == 1 ? '' : '-fluid' }}">

			@if(!empty($section->title))
			<div class="col-sm-12">
				<h2 class="section-heading">{{ $section->title }}</h2>
				{{ $section->font_color }}
			</div>
			@endif

			@foreach($section->articles as $key => $article)
			@php $col = 12/$section->total_column @endphp
			<div class="col-sm-{{ $col }}">
				
				@if(!empty($article->title))
				<h3><b>{{ $article->title }}</b></h3>
				@endif

				@if(!empty($article->subtitle))
				<div><i>{{ $article->subtitle }}</i></div>
				@endif

				@if(!empty($article->image))
				<div class="art-img-box"><img src="{{ asset('cntimgs/'.$article->image) }}" alt="{{ $article->title }}" class="img-responsive"></div>
				@endif			

				@php echo $text->details ? $text->details : '' @endphp

			</div>
			@endforeach

		</section>
	</div>
</div>
@elseif($section->type == 'image' && count($section->images) > 0 )
<div class="container{{ !empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid' }}" style="background-color: {{ !empty($section->bg_color) ? $section->bg_color : 'transparent' }}; color: {{ !empty($section->font_color) ? $section->font_color : 'inherit' }}; padding:{{ !empty($section->padding) ? $section->padding : '0' }};text-align: {{ !empty($section->text_align) ? $section->text_align : '' }};">
	<div class="">
		<section id="{{ $section->id }}" class="container{{ !empty($section->content_width) && $section->content_width == 1 ? '' : '-fluid' }}">

			@if(!empty($section->title))
			<div class="">
				<h2 class="section-heading">{{ $section->title }}</h2>
			</div>
			@endif

			@php $i = 1; $total = $section->images->count() @endphp
			<div class="row">
			@foreach($section->images as $key => $image)
			@php $col = 12/$section->total_column @endphp
			<div class="col-sm-{{ $col }} text-center">
				
				<div class="pro-img-box">
					<div class="pro-img">
						<img src="{{ asset('cntimgs/'.$image->image) }}" alt="{{ $image->title }}" class="img-responsive">
					</div>
					@if(!empty($image->title))
					<div class="mt15 font-md">
						<strong>{{ $image->title }}</strong>
					</div>
					@endif
					@if(!empty($image->caption))
					<div class="mb10">
						{{ $image->caption }}
					</div>
					@endif
					@if($page->parent_id != '3')
					<div class="mt15">
						<a href="{{ url('page',$image->url) }}" class="btn btn-primary btn-product">Read More</a>
					</div>
					@endif
				</div>

			</div>
			@if($total > $section->total_column && $i % $section->total_column == 0)
			</div>
			<div class="row">
			@endif
			@php $i++ @endphp
			@endforeach
			</div>

		</section>
	</div>
</div>
@elseif($section->type == 'slide' && count($section->slides) > 0 )
<div class="container{{ !empty($section->section_width) && $section->section_width == 1 ? '' : '-fluid' }}" style="background-color: {{ !empty($section->bg_color) ? $section->bg_color : 'transparent' }}; color: {{ !empty($section->font_color) ? $section->font_color : 'inherit' }}; padding:{{ !empty($section->padding) ? $section->padding : '0' }};text-align: {{ !empty($section->text_align) ? $section->text_align : '' }};">
	<div class="">
		<section id="{{ $section->id }}" class="">

			@if(!empty($section->title))
			<div class="col-sm-12">
				<h2 class="section-heading">{{ $section->title }}</h2>
			</div>
			@endif

			@php $col = 12/$section->total_column @endphp
			<div class="col-sm-{{ $col }}">

				<div class="row">
					<!-- start carousel -->
					<div class="carousel-container">
					    <div id="myCarousel{{ $section->id }}" class="carousel slide carousel-fade">  
				        	<div class="carousel-inner">
				        	@foreach($section->slides as $key => $slide)
				        		<div class="item {{ $key == 0 ? ' active' : '' }}">	
				        		</span>
				              		<img src="{{ asset('cntimgs/'.$slide->image) }}" alt="{{ $slide->caption }}">
				              		<div class="container">
				                		<div class="carousel-caption">
				                  			<p class="caption animated bounceInUp">{{ $slide->caption }}</p>
				                		</div>
				              		</div>
				            	</div>
				            @endforeach
				        	
						        <!-- Controls -->
						        <a class="left carousel-control" href="#myCarousel{{ $section->id }}" data-slide="prev"><span class="fa fa-chevron-left"></span></a>
						        <a class="right carousel-control" href="#myCarousel{{ $section->id }}" data-slide="next"><span class="fa fa-chevron-right"></span></a>
				      		</div>
				    	</div>
				    </div>

				  	<!-- end carousel -->
					<script>
						// carousel interval
						$("#myCarousel{{ $section->id }}").carousel({interval: 2000});
					  	// Register keyboard events
					  	$(document).keydown(function(e) {
					    	if (e.keyCode === 37) {
					       		// Previous
					       		$(".carousel-control.left").click();
					       		return false;
					    	}
					    	if (e.keyCode === 39) {
					       		// Next
					       		$(".carousel-control.right").click();
					       		return false;
					    	}
						});
					</script>
				</div>

			</div>

		</section>
	</div>
</div>
@endif
@endforeach

@else

<div class="container text-center" style="min-height: 400px; align-items: center;justify-content: center;display: flex;">
	<h2>{{ $page->name }} - No content added</h2>
</div>

@endif

@endsection