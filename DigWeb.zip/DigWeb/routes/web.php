<?php
// cache clearing route call
Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    return back();
});
// view clearing route call
Route::get('/clear-view', function() {
    $exitCode = Artisan::call('view:clear');
    return back();
});
// route clearing route call
Route::get('/clear-route', function() {
    $exitCode = Artisan::call('route:clear');
    return back();
});

// all the public routes
Route::get('/', 'WebController@index')->name('home');

Route::get('page/{slug}', 'WebController@page');

// authenticate routes
Auth::routes();

Route::get('/dboard', 'AdminController@dboard')->name('dboard');
// user routes
Route::group(['middleware' => ['user']], function () {

});
// admin routes
Route::group(['middleware' => ['admin']], function () {
	// pages
    Route::get('/all-pages', 'AdminController@all_pages');
    Route::get('/add-page', 'AdminController@add_page');
    Route::post('/store-page', 'AdminController@store_page');
    Route::get('/edit-page/{id}', 'AdminController@edit_page');
    Route::PATCH('/update-page/{id}', 'AdminController@update_page');
    Route::get('/delete-page/{id}', 'AdminController@delete_page');
    // page contents and sections
    Route::get('/all-page-contents', 'AdminController@all_page_contents');
    
    Route::get('/add-section/{id}', 'SectionController@add_section');
    Route::post('/store-section', 'SectionController@store_section');
    Route::get('/edit-section/{id}', 'SectionController@edit_section');
    Route::PATCH('/update-section/{id}', 'SectionController@update_section');
    Route::get('/delete-section/{id}', 'SectionController@delete_section');
    // texts
    //Route::get('/all-texts', 'TextController@all_texts');
    Route::get('/add-text/{id}', 'TextController@add_text');
    Route::post('/store-text', 'TextController@store_text');
    Route::get('/edit-text/{id}', 'TextController@edit_text');
    Route::PATCH('/update-text/{id}', 'TextController@update_text');
    Route::get('/delete-text/{id}', 'TextController@delete_text');
    // images
    //Route::get('/all-images', 'ImageController@all_images');
    Route::get('/add-image/{id}', 'ImageController@add_image');
    Route::post('/store-image', 'ImageController@store_image');
    Route::get('/edit-image/{id}', 'ImageController@edit_image');
    Route::PATCH('/update-image/{id}', 'ImageController@update_image');
    Route::get('/delete-image/{id}', 'ImageController@delete_image');
    // slides
    //Route::get('/all-slides', 'slideController@all_slides');
    Route::get('/add-slide/{id}', 'ImageController@add_slide');
    Route::post('/store-slide', 'ImageController@store_slide');
    Route::get('/edit-slide/{id}', 'ImageController@edit_slide');
    Route::PATCH('/update-slide/{id}', 'ImageController@update_slide');
    Route::get('/delete-slide/{id}', 'ImageController@delete_slide');
    // articles
    //Route::get('/all-articles', 'ArticleController@all_articles');
    Route::get('/add-article/{id}', 'ArticleController@add_article');
    Route::post('/store-article', 'ArticleController@store_article');
    Route::get('/edit-article/{id}', 'ArticleController@edit_article');
    Route::PATCH('/update-article/{id}', 'ArticleController@update_article');
    Route::get('/delete-article/{id}', 'ArticleController@delete_article');
    // langs
    Route::get('/all-langs', 'SectionController@all_langs');
    Route::get('/add-lang', 'SectionController@add_lang');
    Route::post('/store-lang', 'SectionController@store_lang');
    Route::get('/edit-lang/{id}', 'SectionController@edit_lang');
    Route::PATCH('/update-lang/{id}', 'SectionController@update_lang');
    Route::get('/delete-lang/{id}', 'SectionController@delete_lang');
    // web infos
    Route::get('/web-infos', 'AdminController@web_infos');
    Route::get('/edit-web-infos', 'AdminController@edit_web_infos');
    Route::PATCH('/update-web-infos', 'AdminController@update_web_infos');
    
});
// system routes
Route::group(['middleware' => ['system']], function () {
    // web infos
    //Route::get('/web-infos', 'SystemController@web_infos');
    Route::get('/add-web-infos', 'SystemController@add_web_infos');
    Route::post('/store-web-infos', 'SystemController@store_web_infos');
    //Route::get('/edit-image/{id}', 'AdminController@edit_image');
    //Route::PATCH('/update-image/{id}', 'AdminController@update_image');
    //Route::get('/delete-image/{id}', 'AdminController@delete_image');
});