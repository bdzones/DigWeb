<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('lang_id')->unsigned()->index()->nullable()->default(0);
            $table->integer('user_id')->unsigned()->index()->nullable()->default(0);
            $table->string('full_name')->nullable();
            $table->string('father_name')->nullable();
            $table->string('mother_name')->nullable();
            $table->char('gender')->nullable();
            $table->date('dob')->nullable();
            $table->string('photo')->nullable();
            $table->char('nid')->unique()->nullable();
            $table->char('passport_no')->unique()->nullable();
            $table->string('contact_no')->nullable();
            $table->char('contact_email')->nullable();
            $table->text('permanent_address')->nullable();
            $table->text('mailing_address')->nullable();
            $table->tinyinteger('status')->nullable()->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profiles');
    }
}
