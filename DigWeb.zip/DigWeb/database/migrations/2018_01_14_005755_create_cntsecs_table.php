<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCntsecsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cntsecs', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('cntwb_id')->unsigned()->index()->nullable()->default(0);
            $table->string('title')->nullable();
            $table->tinyinteger('order_no')->nullable()->default(0);
            $table->char('type')->nullable();
            $table->tinyinteger('section_width')->nullable();
            $table->tinyinteger('content_width')->nullable();
            $table->char('padding')->nullable();
            $table->char('bg_color')->nullable();
            $table->char('text_align')->nullable();
            $table->char('font_color')->nullable();
            $table->string('bg_image')->nullable();
            $table->tinyinteger('total_column')->nullable()->default(1);
            $table->integer('user_id')->unsigned()->nullable()->default(0);
            $table->tinyinteger('status')->nullable()->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cntsecs');
    }
}
