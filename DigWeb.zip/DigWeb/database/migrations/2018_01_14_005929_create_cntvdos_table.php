<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCntvdosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cntvdos', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('lang_id')->unsigned()->index()->nullable()->default(0);
            $table->integer('cntwb_id')->unsigned()->index()->nullable()->default(0);
            $table->integer('cntsec_id')->unsigned()->index()->nullable()->default(0);
            $table->integer('cnttxt_id')->unsigned()->index()->nullable()->default(0);
            $table->string('title')->nullable();
            $table->string('caption')->nullable();
            $table->char('type')->nullable();
            $table->string('image')->nullable();
            $table->string('video_link')->nullable();
            $table->integer('order_no')->nullable()->default(0);
            $table->integer('user_id')->unsigned()->index()->nullable()->default(0);
            $table->tinyinteger('status')->nullable()->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cntvdos');
    }
}
