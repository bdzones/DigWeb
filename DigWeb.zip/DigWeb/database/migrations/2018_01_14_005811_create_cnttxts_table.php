<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCnttxtsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cnttxts', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('lang_id')->unsigned()->index()->nullable()->default(0);
            $table->integer('cntwb_id')->unsigned()->index()->nullable()->default(0);
            $table->integer('cntsec_id')->unsigned()->index()->nullable()->default(0);
            $table->string('title')->nullable();
            $table->string('subtitle')->nullable();
            $table->char('type')->nullable();
            $table->tinyinteger('order_no')->nullable()->default(0);
            $table->mediumText('details')->nullable();
            $table->string('image')->nullable();
            $table->integer('user_id')->unsigned()->index()->nullable()->default(0);
            $table->tinyinteger('status')->nullable()->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cnttxts');
    }
}
